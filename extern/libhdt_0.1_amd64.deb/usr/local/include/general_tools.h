#ifndef GENERAL_TOOLS_H
#define GENERAL_TOOLS_H
/**
 *
 * \file general_tools.h
 *
 * Based on:
 * Id: tools.h,v 1.16 2007/03/13 18:11:01 jaus Exp
 * Revision: 1.16
 * Date: 2007/03/13 18:11:01
 *
 * THIS WORK CONTAINS VALUABLE CONFIDENTIAL AND PROPRIETARY INFORMATION.
 * DISCLOSURE OR REPRODUCTION WITHOUT THE WRITTEN AUTHORIZATION OF Applied
 * Perception IS PROHIBITED. THIS UNPUBLISHED WORK BY Applied Perception
 * IS PROTECTED BY THE LAWS OF THE UNITED STATES AND OTHER
 * COUNTRIES. IF PUBLICATION OF THE WORK SHOULD OCCUR, THE FOLLOWING NOTICE
 * SHALL APPLY.
 *
 * "COPYRIGHT (C) 2003 Applied Perception ALL RIGHTS RESERVED."
 *
 * Applied Perception DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL Applied Perception BE LIABLE FOR ANY SPECIAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 *
 *
 **/

/*****************************************************************************/
/* General macro tools */

/* PRINT_F_L prints out the current file name and line number */
#define  PRINT_F_L        printf("file %s, line %d: ", \
                                 __FILE__, \
                                 __LINE__);
#define STRING_EQUAL(s1, s2)  (!strcmp(s1, s2))

#define PRINT_EVERY(format_string, variable, interval, verbose) \
{ \
  static double _last_print_time = 0.0; \
  double _current_print_time; \
  CURRENT_TIME(_current_print_time); \
  if((verbose == TRUE) && \
     ((_current_print_time - _last_print_time) > interval)){ \
    if (variable == NULL) { \
      fprintf(stderr, format_string); \
    } \
    else { \
      fprintf(stderr, format_string, variable); \
    } \
    _last_print_time = _current_print_time; \
  } \
}

#endif
