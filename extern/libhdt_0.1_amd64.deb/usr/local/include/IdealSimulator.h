// BEGIN_QNA_COPYRIGHT
// END_QNA_COPYRIGHT

// BEGIN_QNA_FILE_INFO
// END_QNA_FILE_INFO

///////////////////////////////////////////////////////////
//  IdealSimulator.cpp
//  Definition of the Class IdealSimulator
//  Created on:      5-June-2009
//  Original author: mcsencsits
//  Last Updated:    25-July-2011 by mcsencsits
///////////////////////////////////////////////////////////

#ifndef __IDEAL_SIMULATOR_INCLUDED__
#define __IDEAL_SIMULATOR_INCLUDED__

#include <unistd.h>
#include <pthread.h>
#include <cmath>
#include <cfloat>

#include <clock_tools.h>
#include <ManipulatorInterface.h>

enum JointControlMode{ Position,
                       Velocity,
                       Acceleration,
                       PositionVelocity,
                       PositionTime};
/**
 * \brief This simulator provides an ideal response control for an N-joint serial, rigid-link manipulator
 *         enforcing provided limits on maximum joint velocity and acceleration.  The maximum acceleration is
 *         used to determine a trapezoidal trajectory which is used to update the simulated manipulator's state
 *         in (soft) real-time.
 */
class IdealSimulator : public ManipulatorInterface{
    public:
        IdealSimulator();
        ~IdealSimulator();
        
        virtual ManipulatorError initialize(const ManipulatorParameters & params);
        bool isInitialized();
        
        unsigned int getNumJoints() const;
        
        ManipulatorError getPosition(unsigned int jointIndex, float & position);
        ManipulatorError getPosition(std::vector<float> & positions);
        
        ManipulatorError getVelocity(unsigned int jointIndex, float & velocity);
        ManipulatorError getVelocity(std::vector<float> & velocities);
        
        ManipulatorError getAcceleration(unsigned int jointIndex, float & accel);
        ManipulatorError getAcceleration(std::vector<float> & accelerations);
        
        ManipulatorError setTargetPosition(unsigned int jointIndex, float target);
        ManipulatorError setTargetPosition(const std::vector<float> & targets);
        
        ManipulatorError setTargetVelocity(unsigned int jointIndex, float target);
        ManipulatorError setTargetVelocity(const std::vector<float> & targets);
        
        ManipulatorError setTargetPositionVelocity(unsigned int jointIndex, float targetPosition, float targetVelocity);
        ManipulatorError setTargetPositionVelocity(const std::vector<float> & targetPositions, const std::vector<float> & targetVelocities);
        
        ManipulatorError setTargetPositionTime(unsigned int jointIndex, float targetPosition, float targetTime);
        ManipulatorError setTargetPositionTime(const std::vector<float> & targetPositions, const std::vector<float> & targetTimes);
        
        ManipulatorError getTargetPosition(unsigned int jointIndex, float & target);
        ManipulatorError getTargetPosition(std::vector<float> & targets);
        
        ManipulatorError getTargetVelocity(unsigned int jointIndex, float & target);
        ManipulatorError getTargetVelocity(std::vector<float> & targets);
        
        ManipulatorError getTargetPositionVelocity(unsigned int jointIndex, float & targetPosition, float & targetVelocity);
        ManipulatorError getTargetPositionVelocity(std::vector<float> & targetPositions, std::vector<float> & targetVelocities);
        
        ManipulatorError getTargetPositionTime(unsigned int jointIndex, float & targetPosition, float & targetTime);
        ManipulatorError getTargetPositionTime(std::vector<float> & targetPositions, std::vector<float> & targetTimes);
        
        ManipulatorError getPositionError(unsigned int jointIndex, float & positionError);
        ManipulatorError getPositionError(std::vector<float> & positionError);
        
        ManipulatorError getVelocityError(unsigned int jointIndex, float & velocityError);
        ManipulatorError getVelocityError(std::vector<float> & velocityError);
        
        /**
         * \brief Internal method to routinely call update every once in a while to ensure reported joint states are up to date.
         * \return void
         */
        virtual void controlLoop();
    protected:
        /**
         * \brief Internal method to update state of the simulated manipulator based on amount of time elapsed since
         *         the simulation was initialized.
         * \param[in] elapsedTimeSinceState Amount of time that has elapsed since the simulator began.  Units are in \f$seconds\f$.
         * \return void
         */ 
        virtual void update(double elapsedTimeSinceStart);

        /**
         * \brief Internal method to compute and set accel, coast, and decel times to provide an ideal control response to desiredPosition.
         * \param[in] jointIndex Index value of the joint whose trajectory we want to change.
         * \param[in] desiredPosition Desired final position for the joint referenced by jointIndex.  Units are in \f$radians\f$ for 
         *                            revolute joints and \f$meters\f$ for prismatic joints.
         * \return void
         */
        virtual void setPositionControlTrajectory(unsigned int jointIndex, float desiredPosition);

        /**
         * \brief Internal method to compute and set accel, coast, and decel times to provide an ideal control response to a target
         *         position and desired travel velocity.
         * \param[in] jointIndex Index value of the joint whose trajectory we want to change.
         * \param[in] desiredPosition Desired final position for the joint referenced by jointIndex.  Units are in \f$radians\f$ for 
         *                            revolute joints and \f$meters\f$ for prismatic joints.
         * \param[in] desiredVelocity Desired velocity with which to approach desiredPosition.  Units are in \f$radians/second\f$ for
         *                            revolute joints and \f$meters/second\f$ for prismatic joints.
         * \return void
         * 
         * In the case where desiredVelocity cannot be reached without overshooting the target position the acceleration, coasting, and 
         * deceleration times computed from setPositionControlTrajectory will be used instead.  This means that a call to 
         * setTargetPositionVelocity can result in a joint being in JointControlMode::Position instead of JointControlMode::PositionVelocity.
         */
        virtual void setPositionVelocityControlTrajectory(unsigned int jointIndex, float desiredPosition, float desiredVelocity);

        /**
         * \brief Internal method to compute and set accel, coast, and decel times to provide an ideal control response to a target
         *         position and desired time of arrival.
         * \param[in] jointIndex Index value of the joint whose trajectory we want to change.
         * \param[in] desiredPosition Desired final position for the joint referenced by jointIndex.  Units are in \f$radians\f$ for 
         *                            revolute joints and \f$meters\f$ for prismatic joints.
         * \param[in] desiredTime Desired time of arrival for joint jointIndex from when the command is issued.  Units are in \f$seconds\f$.
         * \return void
         * 
         * In the case where the joint's current state and limits prevent it from reaching desiredPosition in desiredTime seconds the acceleration, 
         * coasting, and deceleration times computed from setPositionControlTrajectory will be used instead.  This means that a call to 
         * setTargetPositionTime can result in a joint being in JointControlMode::Position instead of JointControlMode::PositionTime.
         */
        virtual void setPositionTimeControlTrajectory(unsigned int jointIndex, float desiredPosition, float desiredTime);

        /**
         * \brief Internal method to compute and set accel, coast, and decel times to provide an ideal control response to a target
         *         velocity.
         * \param[in] jointIndex Index value of the joint whose trajectory we want to change.
         * \param[in] desiredVelocity Desired velocity with which to move.  Units are in \f$radians/second\f$ for
         *                            revolute joints and \f$meters/second\f$ for prismatic joints.
         * \return void
         */
        virtual void setVelocityControlTrajectory(unsigned int jointIndex, float targetVelocity);
        
        bool isZero(float);
        
        bool runFlag;                   // flag to tell the controlLoop when to exit
        bool initFlag;                  // flag to indicate when the simulator has been correclty initialized
        pthread_mutex_t dataAccessMutex;// mutex to prevent changes to current targets while performing update
        pthread_t controlLoopThread;
        
        double startTime;               // the system time in seconds when the simulation initialized, this is our 'zero'
        double currentTime;             // the current system time in seconds
        std::vector<double> commandTime;// the elapsed time from startTime in seconds when the last/current command was given for a specific joint 
        
        std::vector<float> currentPosition, currentVelocity, currentAcceleration; // the internal state for each simulated joint
        std::vector<float> targetPosition, targetVelocity, targetTime;            // the last/current command for each joint
        std::vector<float> velocityLimit, accelerationLimit;                      // velocity and acceleration limits of each joint (always positive)
        std::vector<float> positionError, velocityError;                          // difference between desired and current position and velocity
        std::vector<JointControlMode> controlMode;                                // the current control mode for each joint
        std::vector<float> positionAtCommandTime, velocityAtCommandTime; 
        
        // rampUpTime, coastTime, and rampDownTime are measured in seconds from the corresponding commandTime
        std::vector<double> rampUpTime;  // the amount of time a joint needs to spend at max acceleration
        std::vector<double> coastTime;   // the amount of time a joint needs to spend traveling at max||desired velocity
        std::vector<double> rampDownTime;// the amount of time a joint needs to spend at max acceleration in opposite direction
        
        std::vector<float> rampUpDirection;   // the direction of acceleration during rampUpTime, either -1.0 or +1.0
        std::vector<float> rampDownDirection; // the direction of acceleration during rampDownTime, either -1.0 or +1.0
        
        std::vector<float>::const_iterator floatVectorIterator1;
        std::vector<float>::const_iterator floatVectorIterator2;
        
        float epsilon;                          // machine precision value
};

#endif //__IDEAL_SIMULATOR_INCLUDED__
