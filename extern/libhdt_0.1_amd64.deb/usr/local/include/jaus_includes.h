#ifndef JAUS_INCLUDES_H
#define JAUS_INCLUDES_H
/**
 *
 * \file jaus_includes.h
 *
 * $Id$
 * $URL$
 *
 * THIS WORK CONTAINS VALUABLE CONFIDENTIAL AND PROPRIETARY INFORMATION.
 * DISCLOSURE OR REPRODUCTION WITHOUT THE WRITTEN AUTHORIZATION OF Applied
 * Perception IS PROHIBITED. THIS UNPUBLISHED WORK BY Applied Perception
 * IS PROTECTED BY THE LAWS OF THE UNITED STATES AND OTHER
 * COUNTRIES. IF PUBLICATION OF THE WORK SHOULD OCCUR, THE FOLLOWING NOTICE
 * SHALL APPLY.
 *
 * "COPYRIGHT (C) 2003 Applied Perception ALL RIGHTS RESERVED."
 *
 * Applied Perception DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL Applied Perception BE LIABLE FOR ANY SPECIAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 * 
 * THE USER'S RIGHTS TO USE, MODIFY, REPRODUCE, RELEASE, PERFORM, DISPLAY,
 * OR DISCLOSE THE TECHNICAL DATA AND COMPUTER SOFTWARE IN THIS FILE IS
 * RESTRICTED BY THE Applied Perception LICENSE AGREEMENT PROVIDED WITH
 * DELIVERY OF THIS FILE. ANY REPRODUCTION OF TECHNICAL DATA, COMPUTER
 * SOFTWARE, OR PORTIONS THEREOF MARKED WITH THIS LEGEND MUST ALSO
 *
 **/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

/* QNX, Linux, and BSD */
#if defined(QNX) || defined(LINUX) || defined(BSD) || defined(CYGWIN) || defined(WIN32)
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <limits.h>
#include <pthread.h>
#include <math.h>
#include <float.h>
#include <time.h>
#include <sys/types.h>

#if defined(__CYGWIN__)
#include <features.h>
#endif

#include <semaphore.h>
#include <signal.h>
#include <stdarg.h>
#endif

#if !defined(WIN32)
/* Current variants of Linux now support dirent.h, no need to use dir.h */
#include <arpa/inet.h>
#include <dirent.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/ipc.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/sem.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <termios.h>
#else
/* From pthreads 2.0 component */
#include <winsock2.h> /* for timeval, et al */
#include <direct.h>
#include <Ws2tcpip.h>
#include "msvc_timeval.h"
#include <semaphore.h>
#endif

/* Windows CE */
#if defined(_WIN32_WCE)
#include <windows.h>
#include <winsock.h>
#include <time.h>
#include <wince_posix.h>
#endif

/* Rabbit */
#if defined(__Rabbit)
#include <rabbit.h>
#include <TurboTask.h>

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <float.h>
#include <time.h>

#include "rabbit_posix.h"
#endif

#endif
