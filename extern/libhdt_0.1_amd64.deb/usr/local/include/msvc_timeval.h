/*
 * timeval.h    1.3 2003/01/14
 *
 * Defines gettimeofday, timeval, etc. for Win32
 *
 */

#ifndef _TIMEVAL_H
#define _TIMEVAL_H

#ifdef _WIN32


#include <time.h>

#if defined(_MSC_VER) || defined(__BORLANDC__)
#define EPOCHFILETIME (116444736000000000i64)
#else
#define EPOCHFILETIME (116444736000000000LL)
#endif

struct timezone {
    long tz_minuteswest; /* minutes W of Greenwich */
    int tz_dsttime;     /* type of dst correction */
};

__inline int gettimeofday(struct timeval *tv, struct timezone *tz)
{
    FILETIME        ft;
    LARGE_INTEGER   li;
    __int64         t;
    static int      tzflag;
    errno_t         ret;

    if (tv)
    {
        GetSystemTimeAsFileTime(&ft);
        li.LowPart  = ft.dwLowDateTime;
        li.HighPart = ft.dwHighDateTime;
        t  = li.QuadPart;       /* In 100-nanosecond intervals */
        t -= EPOCHFILETIME;     /* Offset to the Epoch time */
        t /= 10;                /* In microseconds */
        tv->tv_sec  = (long)(t / 1000000);
        tv->tv_usec = (long)(t % 1000000);
    }

    if (tz)
    {
        if (!tzflag)
        {
            _tzset();
            tzflag++;
        }
        // Get offset from UTC in seconds
        ret = _get_timezone(&tz->tz_minuteswest);
        if ( ret != 0 ) {
            return -1;
        }
        ret = _get_daylight(&tz->tz_dsttime);
        if ( ret != 0 ) {
            return -1;
        }
        // Convert seconds to minutes
        tz->tz_minuteswest = tz->tz_minuteswest/60;
    }

    return 0;
}

#else  /* _WIN32 */

#include <sys/time.h>

#endif /* _WIN32 */

#endif /* _TIMEVAL_H */

