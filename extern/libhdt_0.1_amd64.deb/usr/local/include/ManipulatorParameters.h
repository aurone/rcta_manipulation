// BEGIN_QNA_COPYRIGHT
// END_QNA_COPYRIGHT
// BEGIN_QNA_FILE_INFO

//  ManipulatorParameters.h: Definition of a class which manages an ordered sequence of
//                           joint parameters.
//  Created Dec 12, 2008 by mcsencsits
//  Updated Oct 03, 2011 by mcsencsits

// END_QNA_FILE_INFO

#if !defined(_MANIPULATOR_PARAMETERS_INCLUDED_)
#define _MANIPULATOR_PARAMETERS_INCLUDED_

#include <vector>
#include <string>
#include "ManipulatorError.h"
#include "ManipulatorJointType.h"
#include "ManipulatorJointParameters.h"

/**
 * \brief This class provides a container for loading, storing, configuring, and accessing parameters used to describe a
 *        serial, rigid-link manipulator.
 */
class ManipulatorParameters
{

public:
   // Lifecycle
    ManipulatorParameters();                                    // Constructor
    ManipulatorParameters(const ManipulatorParameters& params); // Copy Constructor
    virtual ~ManipulatorParameters();                           // Destructor

    //////////////////////////////////////////////////////////////////
    //              OLD INTEFACE, being depricated                  //
    //////////////////////////////////////////////////////////////////
    ManipulatorError getAngle(unsigned int joint, float * angle) const;
    ManipulatorError getAngle(std::vector<float> & angles) const;
    ManipulatorError getJointType(unsigned int joint, ManipulatorJointType* type) const;
    ManipulatorError getJointType(std::vector<ManipulatorJointType> & jointTypes) const;
    ManipulatorError getLength(unsigned int joint, float * length) const;
    ManipulatorError getLength(std::vector<float> & lengths) const;
    ManipulatorError getMaxAccel(unsigned int joint, float * accel) const;
    ManipulatorError getMaxAccel(std::vector<float> & accelerations) const;
    ManipulatorError getMaxPosition(unsigned int joint, float * max) const;
    ManipulatorError getMaxPosition(std::vector<float> & maxPositions) const;
    ManipulatorError getMaxVelocity(unsigned int joint, float * velocity) const;
    ManipulatorError getMaxVelocity(std::vector<float> & velocities) const;
    ManipulatorError getMinPosition(unsigned int joint, float * min) const;
    ManipulatorError getMinPosition(std::vector<float> & minPositions) const;
    unsigned int getNumJoints() const;
    ManipulatorError getOffset(unsigned int joint, float * offset) const;
    ManipulatorError getOffset(std::vector<float> & offsets) const;
    ManipulatorError getResolution(unsigned int joint, float * resolution) const;
    ManipulatorError getResolution(std::vector<float> & resolutions) const;
    ManipulatorError getStowPosition(unsigned int joint, float * stowPos) const;
    ManipulatorError getStowPosition(std::vector<float> & stowPositions) const;
    ManipulatorError getTwist(unsigned int joint, float * twist) const;
    ManipulatorError getTwist(std::vector<float> & twists) const;
    ManipulatorError getEncoderOffset(unsigned int joint, float * encOffset) const;
    ManipulatorError getEncoderOffset(std::vector<float> & encOffsets) const;
    ManipulatorError getEncoderScale(unsigned int joint, float * encScale) const;
    ManipulatorError getEncoderScale(std::vector<float> & encScales) const;
    bool haveDHParams() const;
    bool haveMaxAcceleration() const;
    bool haveMaxVelocity() const;
    bool havePositionLimits() const;
    bool haveResolution() const;
    bool haveStowPosition() const;
    bool haveEncParams() const;
    ManipulatorError initialize(std::string & paramFileName);
    bool isInitialized() const;

    ///////////////////////////////////////////////////////////////
    //          NEW INTERFACE, being developed                   //
    ///////////////////////////////////////////////////////////////
    unsigned int NumJoints() const;

    ManipulatorJointParameters& Joint(unsigned int ix);
    const ManipulatorJointParameters& Joint(unsigned int ix) const;

    ManipulatorError Insert(unsigned int ix, ManipulatorJointParameters& params);
    ManipulatorError Append(ManipulatorJointParameters& params);
    ManipulatorError Remove(unsigned int ix);

    //ManipulatorError Save(std::string& ofn) const;
    //ManipulatorError Load(std::string& ifn);

    // Operators, these methods provide some convenient functionality
    //ManipulatorParameters& operator= (const ManipulatorParameters& rhs); // copy assignment, using default
    bool operator==(const ManipulatorParameters& rhs) const;
    bool operator!=(const ManipulatorParameters& rhs) const;

private:
    /**
     * \brief Vector of angle parameters for Denavit-Hartenberg respresentation of joints.
     * 
     * If jointType is REVOLUTE then this parameter should be equal to zero because this is the variable
     * parameter for a REVOLUTE joint.  Units are in \f$radians\f$.
     */
    std::vector<float> dhAngle;
    /**
     * \brief Vector of length parameters for Denavit-Hartenberg representation of joints.
     * 
     * Units are in \f$meters\f$.
     */
    std::vector<float> dhLength;
    /**
     * \brief Vector of offset parameters for Denavit-Hartenberg representation of joints.
     * 
     * If jointType is PRISMATIC then this parameter should be equal to zero because this is the variable
     * parameter for a PRISMATIC joint.  Units are in \f$meters\f$.
     */
    std::vector<float> dhOffset;
    /**
     * \brief Vector of twist parameters for Denavit-Hartenberg representation of joints.
     * 
     * Units are in \f$radians\f$.
     */
    std::vector<float> dhTwist;
    /**
     * \brief The value of haveParams is interpreted bit-wise and reflects whether the parameters {jointResolution,
     * maxAcceleration, maxVelocity, DH parameters, position limits} are set and known.
     * 
     * Bit-wise interpretation of haveParams:\n
     * Bit | Meaning\n
     * ---------------\n
     * 0   | Have specified joint position measurement resolutions\n
     * 1   | Have specified maximum value for joint velocities\n
     * 2   | Have specified maximum value for joint accelerations\n
     * 3   | Have specified values for DH parameters\n
     * 4   | Have specified minimum and maximum values for joint positions\n
     * 5   | Have specified stowed joint positions\n
     * 6   | Have specified encoder offset and scale values\n
     * 7   | X\n
     */
    unsigned char haveParams;
    /**
     * \brief Initialization flag, true if parameters have been correctly initialized, false otherwise.
     */
    bool initFlag;
    /**
     * \brief Vector of specified measurement resolutions for each joint.
     * 
     * Units are in \f$radians\f$ for revolute joints and \f$meters\f$ for prismatic joints.
     */
    std::vector<float> jointResolution;
    /**
     * \brief Vector of values representing joint type.
     * 
     * Denavit-Hartenberg joints can be:\n
     *  ManipulatorJointType::Revolute()\n
     *  ManipulatorJointType::Prismatic()\n
     */
    std::vector<ManipulatorJointType> jointType;
    /**
     * \brief Vector of maximum acceleration values capable/allowed by each joint in either direction.
     * 
     * Units are \f$radians/second^2\f$ for revolute joints and \f$meters/second^2\f$ for prismatic joints.
     * 
     * \note Maximum torque/force values for joints may be more useful/accurate for control of physical manipulators but will
     * require a more technical implementation.
     */
    std::vector<float> maxAcceleration;
    /**
     * \brief Vector of maximum position values for each joint.
     * 
     * Units are \f$radians\f$ for revolute joints and \f$meters\f$ for prismatic joints.
     */
    std::vector<float> maxPosition;
    /**
     * \brief Vector of maximum velocity values capable/allowed by each joint in either direction.
     * 
     * Units are in \f$radians/second\f$ for revolute joints and \f$meters/second\f$ for prismatic joints.  Technically this
     * value is maximum <b>speed</b>.
     */
    std::vector<float> maxVelocity;
    /**
     * \brief Vector of minimum position values for each joint.
     * 
     * Units are \f$radians\f$ for revolute joints and \f$meters\f$ for prismatic joints.
     */
    std::vector<float> minPosition;
    /**
     * \brief Number of Denavit-Hartenberg describable joints in manipulator.
     * 
     * The value of numJoints is set to 0 when baseManipulatorParameters is first instantiated.  This value is set by calling
     * initialize with a valid manipulator parameters file.
     * 
     * \note The number of joints is not necessarily equal to the number of actuators!!  Redundant actuator schemes could
     * potentially be utilized for operating an individual joint.
     */
    unsigned int numJoints;
    /**
     * \brief Vector of position values for each joint of manipulator when in stowed configuration.
     * 
     * Units are \f$radians\f$ for revolute joints and \f$meters\f$ for prismatic joints.
     */
    std::vector<float> stowPosition;
    /**
     * \brief Vector of encoder offset values for each joint of manipulator.
     * 
     * Units are the same as the raw output (typically ticks).
     */
    std::vector<float> enc_offset;
    /**
     * \brief Vector of encoder scale factors for each joint of manipulator.
     * 
     * Values can be positive or negative and convert raw position feedback data into radians (typically \f$radians/tick\f$ or \f$meters/tick\f$).
     */
    std::vector<float> enc_scale;

    std::vector<ManipulatorJointParameters> mJoint; // Vector of joint parameters, ordered proximal to distal (0 -> N-1)

    ManipulatorError loadParamFile(std::string & paramFileName);
    ManipulatorError parseTextFile(std::string & paramFileName);
    ManipulatorError parseXmlFile(std::string & paramFileName);

};
#endif // !defined(_MANIPULATOR_PARAMETERS_INCLUDED_)
