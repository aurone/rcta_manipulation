#ifndef JAUS_MESSAGE_H
#define JAUS_MESSAGE_H
/**
 *
 * \file jaus_message.h
 *
 * $Id: jaus_message.h,v 1.4 2006/04/18 14:11:16 jaus Exp $
 * $Revision: 1.4 $
 * $Date: 2006/04/18 14:11:16 $
 *
 * THIS WORK CONTAINS VALUABLE CONFIDENTIAL AND PROPRIETARY INFORMATION.
 * DISCLOSURE OR REPRODUCTION WITHOUT THE WRITTEN AUTHORIZATION OF Applied
 * Perception IS PROHIBITED. THIS UNPUBLISHED WORK BY Applied Perception
 * IS PROTECTED BY THE LAWS OF THE UNITED STATES AND OTHER
 * COUNTRIES. IF PUBLICATION OF THE WORK SHOULD OCCUR, THE FOLLOWING NOTICE
 * SHALL APPLY.
 *
 * "COPYRIGHT (C) 2003-2005 Applied Perception ALL RIGHTS RESERVED."
 *
 * Applied Perception DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL Applied Perception BE LIABLE FOR ANY SPECIAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 * 
 * THE USER'S RIGHTS TO USE, MODIFY, REPRODUCE, RELEASE, PERFORM, DISPLAY,
 * OR DISCLOSE THE TECHNICAL DATA AND COMPUTER SOFTWARE IN THIS FILE IS
 * RESTRICTED BY THE Applied Perception LICENSE AGREEMENT PROVIDED WITH
 * DELIVERY OF THIS FILE. ANY REPRODUCTION OF TECHNICAL DATA, COMPUTER
 * SOFTWARE, OR PORTIONS THEREOF MARKED WITH THIS LEGEND MUST ALSO
 *
 *
 **/

/* dependencies */
#include <jaus_base.h>

/********** JAUS MESSAGE HEADER **********/

#ifdef ETG_TRANSPORT_1
/* JUDP V1 Header bytes (from AS5669). */
#define JLIB_JAUS_MSG_MESSAGE_PROPERTIES_BYTE1                1
#define JLIB_JAUS_MSG_MESSAGE_PROPERTIES_BYTE2                0
#else
/* RA 3.2/3.3 Header bytes. */
#define JLIB_JAUS_MSG_MESSAGE_PROPERTIES_BYTE1                0
#define JLIB_JAUS_MSG_MESSAGE_PROPERTIES_BYTE2                1
#endif

/* JAUS Header Version - 0x01 is Version 3.0/3.1 compatible. */
/*                       0x02 is Version 3.2/3.3 compatible */
/*                       0x03-0x3F are reserved for future use. */
/* Only 3.2/3.3 is supported in this release. */
#define JLIB_JAUS_MSG_HEADER_VERSION                          0x02

#define JLIB_JAUS_MSG_COMMAND_BYTE                            2
#define JLIB_JAUS_MSG_DEST_INSTANCE_ID_BYTE                   4
#define JLIB_JAUS_MSG_DEST_COMPONENT_ID_BYTE                  5
#define JLIB_JAUS_MSG_DEST_NODE_ID_BYTE                       6
#define JLIB_JAUS_MSG_DEST_SUBSYSTEM_ID_BYTE                  7
#define JLIB_JAUS_MSG_SRC_INSTANCE_ID_BYTE                    8
#define JLIB_JAUS_MSG_SRC_COMPONENT_ID_BYTE                   9
#define JLIB_JAUS_MSG_SRC_NODE_ID_BYTE                        10
#define JLIB_JAUS_MSG_SRC_SUBSYSTEM_ID_BYTE                   11
#define JLIB_JAUS_MSG_DATA_CONTROL_BYTE                       12
#define JLIB_JAUS_MSG_SEQUENCE_NUMBER_BYTE                    14

/********** ROUTING CONSTANTS **********/
/* These are constants that are used by the jLibInitialize() function to
   specify this node and subsystem, since the component may not know
   a-priori. Note that 0 is an invalid id in the JAUS spec, so these won't
   conflict. */
#define JLIB_JAUS_THIS_INSTANCE                      0
#define JLIB_JAUS_THIS_COMPONENT                     0
#define JLIB_JAUS_THIS_NODE                          0
#define JLIB_JAUS_THIS_SUBSYSTEM                     0
#define JLIB_JAUS_INVALID_ID                         0
#define JLIB_JAUS_BROADCAST_ID                       255

/********** JAUS MESSAGE IDS **********/
#define JLIB_JAUS_MSG_START_ID                            0x0000
#define JLIB_JAUS_MSG_END_ID                              0xFFFF
#define JLIB_JAUS_MAX_MSG_ID                              0xFFFF

/* COMMAND MESSAGES */
#define JLIB_JAUS_COMMAND_CLASS_START_ID                  0x0000
#define JLIB_JAUS_COMMAND_CLASS_END_ID                    0x1FFF

/* QUERY MESSAGES */
#define JLIB_JAUS_QUERY_CLASS_START_ID                    0x2000
#define JLIB_JAUS_QUERY_CLASS_END_ID                      0x3FFF

/* REPORT MESSAGES */
#define JLIB_JAUS_REPORT_CLASS_START_ID                   0x4000
#define JLIB_JAUS_REPORT_CLASS_END_ID                     0x5FFF


/********** JAUS MESSAGE SIZE **********/
/* The following are the JAUS-specification-defined sizes of the message
   header and data areas of the message, as well as the maximum JAUS message
   size. */
#define JLIB_JAUS_HEADER_LENGTH                             16
#define JLIB_JAUS_MAX_DATA_LENGTH                           4080
#define JLIB_JAUS_MAX_MESSAGE_LENGTH       (JLIB_JAUS_HEADER_LENGTH +   \
                                            JLIB_JAUS_MAX_DATA_LENGTH)

/********** JAUS DATA FLAG CONSTANTS ******/
#define JLIB_JAUS_HEADER_DATA_FLAG_ONLY_PACKET_IN_SINGLE_MESSAGE            0x00
#define JLIB_JAUS_HEADER_DATA_FLAG_FIRST_PACKET_IN_MULTI_PACKET_MESSAGE     0x01
#define JLIB_JAUS_HEADER_DATA_FLAG_NORMAL_DATA_PACKET                       0x02
#define JLIB_JAUS_HEADER_DATA_FLAG_RETRANSMITTED_DATA_PACKET                0x04
#define JLIB_JAUS_HEADER_DATA_FLAG_LAST_PACKET_IN_MULTI_PACKET_MESSAGE      0x08

/********** JAUS PRIORITY CONSTANTS **********/
#define JLIB_JAUS_LOW_MESSAGE_PRIORITY                      0
#define JLIB_JAUS_DEFAULT_MESSAGE_PRIORITY                  6
#define JLIB_JAUS_HIGH_MESSAGE_PRIORITY                     11
#define JLIB_JAUS_LOW_SAFETY_CRITICAL_MESSAGE_PRIORITY      12
#define JLIB_JAUS_HIGH_SAFETY_CRITICAL_MESSAGE_PRIORITY     15

/********** JAUS ACK/NAK CONSTANTS **********/
#define JLIB_JAUS_NO_ACK_REQUIRED                           0
#define JLIB_JAUS_ACK_REQUIRED                              1
#define JLIB_JAUS_MESSAGE_ACKNOWLEDGED                      2
#define JLIB_JAUS_MESSAGE_NOT_ACKNOWLEDGED                  3

/********** JAUS SERVICE CONNECTION CONSTANTS **********/
#define JLIB_JAUS_NORMAL_CONNECTION                         0
#define JLIB_JAUS_SERVICE_CONNECTION                        1

/********** JAUS EXERIMENTAL MESSAGE CONSTANTS **********/
#define JLIB_JAUS_NORMAL_MESSAGE                            0
#define JLIB_JAUS_EXPERIMENTAL_MESSAGE                      1

/********** MESSAGE ENCODING TYPES *************/
typedef enum {
  SYM_ENCODING_NOT_SPECIFIED = 0,
  SYM_ENCODING_JAUS = 1,
  SYM_ENCODING_REFERENCE = 2,
  SYM_ENCODING_MEMCPY = 3
} SymphonyMsgEncoding_t;

typedef struct {
  JLIB_UBYTE priority;
  JLIB_UBYTE ack_nack;
  JLIB_UBYTE service_connection;
  JLIB_UBYTE experimental_message;
  JLIB_UBYTE jaus_version;
  JLIB_USHORT command_code;

  JLIB_UBYTE dest_instance_id;
  JLIB_UBYTE dest_component_id;
  JLIB_UBYTE dest_node_id;
  JLIB_UBYTE dest_subsystem_id;

  JLIB_UBYTE src_instance_id;
  JLIB_UBYTE src_component_id;
  JLIB_UBYTE src_node_id;
  JLIB_UBYTE src_subsystem_id;

  JLIB_USHORT data_length;
  JLIB_UBYTE data_flags;
  JLIB_USHORT sequence_number;
  SymphonyMsgEncoding_t encoding;
  
} jLibJAUSMessageHeader_t;

typedef struct {

  /// Parsed message header info
  jLibJAUSMessageHeader_t header;

  /// Full message including header.
  JLIB_UBYTE message_data[JLIB_JAUS_MAX_MESSAGE_LENGTH];

} jLibJAUSMessage_t;

typedef struct {
  JLIB_USHORT number_of_messages;
  JLIB_USHORT message_size[65535];
  JLIB_UBYTE *message_data[65535];
} jLibPackedMessages_t;

typedef struct {
  JLIB_UBYTE r;
  JLIB_UBYTE g;
  JLIB_UBYTE b;
} JLIB_RGB;

typedef struct {
  JLIB_UBYTE r;
  JLIB_UBYTE g;
  JLIB_UBYTE b;
  JLIB_UBYTE a;
} JLIB_RGBA;

typedef union {
  JLIB_UBYTE b;
  JLIB_SHORT s;
  JLIB_INT i;
  JLIB_LONG li;
  JLIB_USHORT us;
  JLIB_UINT ui;
  JLIB_ULONG uli;
  JLIB_FLOAT f;
  JLIB_DOUBLE lf;
  JLIB_RGB rgb;
  JLIB_RGBA rgba;
} jLibDataTypeUnion_t;

typedef enum {
  WM_BYTE = 0, 
  WM_SHORT_INTEGER = 1, 
  WM_INTEGER = 2, 
  WM_LONG_INTEGER = 3, 
  WM_UNSIGNED_SHORT_INTEGER = 4,
  WM_UNSIGNED_INTEGER = 5, 
  WM_UNSIGNED_LONG_INTEGER = 6, 
  WM_FLOAT = 7, 
  WM_LONG_FLOAT = 8, 
  WM_RGB = 9,
  WM_RGBA = 10,
  WM_DONTCARE = 11,
  WM_UNKNOWN = 12,
  WM_DT_MAX = 12
} jLibDataTypeEnumeration_t;

typedef struct {
  jLibDataTypeEnumeration_t data_type;
  jLibDataTypeUnion_t data;
} jLibDataVariant_t;

/* Defined per RA3.3 specification, for data conditions */
typedef enum {
  BOUND_EQ = 0,
  BOUND_NEQ = 1,
  BOUND_IN_INCL = 2,
  BOUND_IN_EXCL = 3,
  BOUND_OUT_INCL = 4,
  BOUND_OUT_EXCL = 5,
  BOUND_GTE = 6,
  BOUND_GT = 7,
  BOUND_LTE = 8,
  BOUND_LT = 9,
  BOUND_NONE = 10,  /* Specifically indicate that there is no data condition. */
  BOUND_UNKNOWN = 11,
  BOUND_MAX = 11
} jLibBoundaryTypeEnumeration_t;

/* Used by event manager and others to get information about
 * a field in a message provided by a specific Interface
 */
typedef struct {
  jLibDataTypeEnumeration_t field_type;
  void *the_field;  // pointer to the field data, must be coerced to field_type before ref.
  int message_code; // back-ref to the message_code this field is defined for.
  int field_number; // JAUS field number within the message data record
  //min, max value for this field (if any) defined by the Interface spec
  int min_inclusive;  // JLIB_TRUE if constraint range min limit is inclusive
  jLibDataTypeUnion_t spec_min;
  int max_inclusive;  // JLIB_TRUE if constraint range max limit is inclusive
  jLibDataTypeUnion_t spec_max;
} FieldInfo_t;

#ifdef __cplusplus
extern "C" {
#endif
  /********************************************************** jaus_utils.cpp **/
  /*!
   * \brief Copy header and message body from \c header and \c *data to \c *message.
   *     Serialize the header and message data into the
   *     jaus_message->message_data buffer.
   *
   * Returns -1 if src JAUS version byte is > 0x03 or JAUS src ID is all zeros.
   *
   * \param header - a valid JAUS message header.
   * \param data - pointer to a sequence of message bytes.  If NULL, no data is
   *     copied, but function can stil return JLIB_TRUE.
   * \param[in, out] jaus_message - pointer to a JAUS message structure.
   *
   * \return JLIB_TRUE if header is valid, else -1.
   */
  JLIB_SHORT jLibPackJAUSMessage( jLibJAUSMessageHeader_t header,
                                  JLIB_UBYTE *data,
                                  jLibJAUSMessage_t *jaus_message);

  /*!
   * \brief - Set the fields in \c header to the corresponding params.
   *
   * This convenience function *always* sets jaus_version = 0x01 (JAUS 3.0)
   *
   * There is no validation.  Should check for NULL header pointer, but doesn't.
   *
   */
  void jLibFillJAUSMessageHeader( JLIB_UBYTE priority,
                                  JLIB_UBYTE ack_nack,
                                  JLIB_UBYTE service_connection,
                                  JLIB_UBYTE experimental_message,
                                  JLIB_USHORT command_code,
                                  JLIB_UBYTE dest_instance_id,
                                  JLIB_UBYTE dest_component_id,
                                  JLIB_UBYTE dest_node_id,
                                  JLIB_UBYTE dest_subsystem_id,
                                  JLIB_UBYTE src_instance_id,
                                  JLIB_UBYTE src_component_id,
                                  JLIB_UBYTE src_node_id,
                                  JLIB_UBYTE src_subsystem_id,
                                  JLIB_USHORT data_length,
                                  JLIB_UBYTE data_flags,
                                  jLibJAUSMessageHeader_t *header);
  /*!
   * \brief Set the fields in \c header using the encoded bytes in
   *      \c jaus_message->message_data.
   *
   * \return JLIB_TRUE for success, else -1 if src JAUS version byte
   * is > 0x03 or if any of the src or dest component or instance id
   * fields are zero.
   *
   */
  JLIB_INT jLibUnpackJAUSMessageHeader( jLibJAUSMessageHeader_t *header,
                                        jLibJAUSMessage_t *jaus_message);
  /*!
   * \brief Takes a message and a component_id and sees if the
   *        source of the message is the same as the component_id.
   *
   * \param message
   * \param id
   * \return JLIB_TRUE if the JAUS ID in message matches \c id.
   *
   */
  JLIB_INT jLibCompareMessageSource( jLibJAUSMessage_t *message,
                                     jLibComponentId_t *id);
  /*!
   *
   *
   *
   */
  void jLibGetAndPackTime(struct timeval timestamp,JLIB_UBYTE *buf);
  void jLibUnpackTime(struct timeval *timestamp, JLIB_UBYTE *buf);

  /*!
   * \brief Returns current time as floating point seconds since beginning of month
   *     per the JAUS specification.
   *
   * \return seconds since the beginning of the current month UCT(GMT).
   */
  JLIB_DOUBLE jLibGetJAUSTime(void);

  /*!
   * \brief Converts a timeval to equivalent floating point seconds.
   *
   * \param timestamp the timeval to convert.
   *
   * \return equivalent time as floating point value.
   */
  JLIB_DOUBLE jLibConvertJAUSTimeToContinuousTime(struct timeval *timestamp);

  /*!
   * \brief Convert a UTC(GMT) time in seconds to time in seconds since the
   *      beginning of the current month per JAUS specification.
   *
   * \param t floating point seconds UTC(GMT).
   *
   * \return floating point seconds since the beginning of the current month.
   *
   */
  JLIB_DOUBLE jLibConvertProcessTimeToJAUSTime( JLIB_DOUBLE t );

  /*!
   * \brief return JLIB_TRUE if two JAUS IDs are equal.
   */
  JLIB_INT jLibEqualComponentIds(jLibComponentId_t comp1, jLibComponentId_t comp2);

  /************************************************************* support.cpp **/
  JLIB_INT jLibJAUSBitTest(JLIB_UBYTE byte, JLIB_UBYTE bit);
  JLIB_INT jLibJAUSCreateNewPackedMessage(jLibPackedMessages_t *packed_message);
  JLIB_INT jLibJAUSCleanUpPackedMessageData(jLibPackedMessages_t *packed_messages);
  JLIB_INT jLibJAUSPackByte(JLIB_BYTE value, jLibPackedMessages_t *packed_message);
  JLIB_INT jLibJAUSPackUByte(JLIB_UBYTE value, jLibPackedMessages_t *packed_message);
  JLIB_INT jLibJAUSPackShort(JLIB_SHORT value, jLibPackedMessages_t *packed_message);
  JLIB_INT jLibJAUSPackUShort(JLIB_USHORT value, jLibPackedMessages_t *packed_message);
  JLIB_INT jLibJAUSPackInt(JLIB_INT value, jLibPackedMessages_t *packed_message);
  JLIB_INT jLibJAUSPackUInt(JLIB_UINT value, jLibPackedMessages_t *packed_message);
  JLIB_INT jLibJAUSPackLong(JLIB_LONG value, jLibPackedMessages_t *packed_message);
  JLIB_INT jLibJAUSPackULong(JLIB_ULONG value, jLibPackedMessages_t *packed_message);
  JLIB_INT jLibJAUSPackFloat(JLIB_FLOAT value, jLibPackedMessages_t *packed_message);
  JLIB_INT jLibJAUSPackDouble(JLIB_DOUBLE value, jLibPackedMessages_t *packed_message);

#ifdef __cplusplus
}
#endif


#endif
