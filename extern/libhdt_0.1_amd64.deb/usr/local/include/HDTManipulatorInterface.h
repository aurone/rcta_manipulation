// BEGIN_QNA_COPYRIGHT
// END_QNA_COPYRIGHT
// BEGIN_QNA_FILE_INFO

// HDTManipulatorInterface.h: Definition of concrete interface to HDT manipulator
// Created Sep 26, 2012 by matthew.csencsits
// Updated Oct 23, 2012 by matthew.csencsits

// END_QNA_FILE_INFO

#ifndef __HDT_MANIPULATOR_INTERFACE_INCLUDED__
#define __HDT_MANIPULATOR_INTERFACE_INCLUDED__

// standard includes
#include <pthread.h>
#include <cmath>

// symphony includes
//#include <clock_tools.h>
#include "ManipulatorInterface.h"

// HDT specific includes
#include "CANMessage.h"
#include "RADMessages.h"
#include <ntcan.h>

// local includes
//#include "CircularSumQueue.h"


class HDTManipulatorInterface : public ManipulatorInterface{
public:
   
   HDTManipulatorInterface();
   virtual ~HDTManipulatorInterface();
   
   ManipulatorError initialize(const ManipulatorParameters &params);
   bool isInitialized();
   ManipulatorError shutdown();
   
   /**
    * \brief Indicates whether or not the interface is handling an error condition by resetting joint controllers.
    * \return true if errors were detected and joint controllers were reset.  Requires acknowledgment to resume sending motion commands.\n
    *         false if no errors have occurred and motion commands are being sent to the joint controllers.
    */
   bool resetOccurred();

   /**
    * \brief Acknowledges notification of errors resulting in a reset of joint controllers.
    * \return ManipulatorError::NO_ERROR is returned if all joint controllers have been properly reset.\n
    *         ManipulatorError::INTERFACE_NOT_INITIALIZED is returned if the interface has not been correctly initialized.\n
    *         ManipulatorError::RESET_ERROR is returned if there are joint controllers which have not acknowledged the reset command.
    */
   ManipulatorError acknowledgeReset();

   unsigned int getNumJoints() const;
   
   ////////////////////////////////////////
   // Get current/latest state of joints //
   ////////////////////////////////////////
   ManipulatorError getPosition(unsigned int jointIndex, float & position);
   ManipulatorError getPosition(std::vector<float> & positions);
   
   ManipulatorError getVelocity(unsigned int jointIndex, float & velocity);
   ManipulatorError getVelocity(std::vector<float> & velocities);
   
   ManipulatorError getTorque(unsigned int jointIndex, float & torque);
   ManipulatorError getTorque(std::vector<float> & torques_forces);

   ManipulatorError getPositionError(unsigned int jointIndex, float & positionError);
   ManipulatorError getPositionError(std::vector<float> & positionError);
   
   ManipulatorError getVelocityError(unsigned int jointIndex, float & velocityError);
   ManipulatorError getVelocityError(std::vector<float> & velocityError);
   
   ManipulatorError getMotorCurrent(unsigned int jointIndex, float & current);
   ManipulatorError getMotorCurrent(std::vector<float> & motorCurrent);
   
   ////////////////////////////////
   // Set next command of joints //
   ////////////////////////////////
   ManipulatorError setTargetPositionVelocity(unsigned int jointIndex, float targetPosition, float targetVelocity);
   ManipulatorError setTargetPositionVelocity(const std::vector<float> & targetPositions, const std::vector<float> & targetVelocities);
   
   ManipulatorError setTargetTorque(unsigned int jointIndex, float target);
   ManipulatorError setTargetTorque(const std::vector<float> & targets);
   
   ManipulatorError setMotorCurrentLimit(unsigned int jointIndex, float limit);
   ManipulatorError setMotorCurrentLimit(const std::vector<float> & limits);
   
   ManipulatorError setTargetInertia(unsigned int jointIndex, float inertia);
   ManipulatorError setTargetInertia(const std::vector<float> & inertias);

   ManipulatorError setTargetStiffness(unsigned int jointIndex, float stiffness);
   ManipulatorError setTargetStiffness(const std::vector<float> & stiffness);

   ManipulatorError setTargetDamping(unsigned int jointIndex, float damping);
   ManipulatorError setTargetDamping(const std::vector<float> & damping);

   //////////////////////////////////////////
   // Get current/latest command of joints //
   //////////////////////////////////////////
   ManipulatorError getTargetPosition(unsigned int jointIndex, float & target);
   ManipulatorError getTargetPosition(std::vector<float> & targets);
   
   ManipulatorError getTargetVelocity(unsigned int jointIndex, float & target);
   ManipulatorError getTargetVelocity(std::vector<float> & targets);
   
   ManipulatorError getTargetPositionVelocity(unsigned int jointIndex, float & targetPosition, float & targetVelocity);
   ManipulatorError getTargetPositionVelocity(std::vector<float> & targetPositions, std::vector<float> & targetVelocities);
   
   ManipulatorError getTargetTorque(unsigned int jointIndex, float & target);
   ManipulatorError getTargetTorque(std::vector<float> & targets);

   ManipulatorError getMotorCurrentLimit(unsigned int jointIndex, float limit);
   ManipulatorError getMotorCurrentLimit(std::vector<float> & limits);

   ManipulatorError getTargetInertia(unsigned int jointIndex, float inertia);
   ManipulatorError getTargetInertia(const std::vector<float> & inertias);

   ManipulatorError getTargetStiffness(unsigned int jointIndex, float stiffness);
   ManipulatorError getTargetStiffness(const std::vector<float> & stiffness);

   ManipulatorError getTargetDamping(unsigned int jointIndex, float damping);
   ManipulatorError getTargetDamping(const std::vector<float> & damping);

   /////////////////////////////////////
   // Get current/latest fault status //
   /////////////////////////////////////
   bool isControllable();
   bool haveSupply();
   bool haveCommunication();
   
   ManipulatorError getSoftwareState(unsigned int jointIndex, RAD::SWState & state);
   ManipulatorError getSoftwareState(std::vector<RAD::SWState> & states);

   ManipulatorError getBITStatus(unsigned int jointIndex, RAD::BITStatus & status);
   ManipulatorError getBITStatus(std::vector<RAD::BITStatus> & status);

   ManipulatorError getMotorTemperature(unsigned int jointIndex, float & temp);
   ManipulatorError getMotorTemperature(std::vector<float> & temp);
   
   ManipulatorError getMotorTempFaultStatus(unsigned int jointIndex, bool & status);
   ManipulatorError getMotorTempFaultStatus(std::vector<bool> & status);

   ManipulatorError getMotorVoltFaultStatus(unsigned int jointIndex, bool & status);
   ManipulatorError getMotorVoltFaultStatus(std::vector<bool> & status);

   ManipulatorError getMotorCurrentFaultStatus(unsigned int jointIndex, bool & status);
   ManipulatorError getMotorCurrentFaultStatus(std::vector<bool> & status);

   ManipulatorError getCommsFaultStatus(unsigned int jointIndex, bool & status);
   ManipulatorError getCommsFaultStatus(std::vector<bool> & status);

   ManipulatorError getMiscFaultStatus(unsigned int jointIndex, bool & status);
   ManipulatorError getMiscFaultStatus(std::vector<bool> & status);

   double getLastUpdateTime();  // returns number of seconds from initialization update() was last called
                                // used to determine if controlLoop has been blocked for an extended period of time
   
   double getLastUpdateFrequency();  // returns 1/(latest time difference between executions of update)
   
   
protected:
   void Update(/*double elapsed_time*/); // This function parses CAN messages for the current status,
                                         // updates member variables accordingly, and processes/sends
                                         // any new commands.  It is called from controlLoop().
   void ControlLoop();
   friend void* HDTControlLoopWrapper(void *);
   
   template <class T>
   ManipulatorError GetValueFromVector(unsigned int jix, T & val, std::vector<T> & vec);
   template <class T>
   ManipulatorError SetValueInVector(unsigned int jix, std::vector<T> & vec, T & val);

   template <class T>
   ManipulatorError GetValuesFromVectors(unsigned int jix, unsigned int valCnt, ...);
   template <class T>
   ManipulatorError SetValuesInVectors(unsigned int jix, unsigned int valCnt, ...);

   template <class T>
   ManipulatorError CopyVectors(bool checkControllable, bool checkComms, unsigned int pairCnt, ...);

   bool OpenCANBus();
   void CloseCANBus();
   void ParseCANMessages();
   bool QueueCANMessage(HDT::CANMessage& msg);
   bool SendCANMessages();
   bool ReadCANMessages();

   bool ResetJoints();
   void StopJoints();

   bool run_flag;                    // flag to tell the controlLoop when to exit
   bool init_flag;                   // flag to indicate when the decon manipulator interface has been correctly initialized
   pthread_mutex_t data_access_mutex;
   pthread_t control_loop_thread;
   
   NTCAN_HANDLE ntcan_handle;
   NTCAN_RESULT ntcan_result;        // return status of each call to the NTCAN library. 0 -> all is good, !0 -> error
   
   int32_t ntcan_net_id;
   uint32_t ntcan_mode;
   int32_t ntcan_tx_queue_size;
   int32_t ntcan_rx_queue_size;
   int32_t ntcan_tx_timeout;
   int32_t ntcan_rx_timeout;
   uint32_t ntcan_baud;
   int32_t ntcan_msg_cnt;
   int32_t ntcan_buffer_size;
   int32_t ntcan_buffer_count;
   uint32_t ntcan_rx_timeout_count;
   CMSG* ntcan_msg_buffer;

   double start_time;
   double last_update_time; // difference in seconds between when update() was last called and start_time
   double last_update_freq;
   
   std::vector<float> target_position;               // last commanded joint position
   std::vector<float> target_velocity;               // last commanded joint velocity
   std::vector<float> target_torque;                 // last commanded joint torque, only works when joint is in impedance mode (non-zero inertia given)

   std::vector<float> target_inertia;
   std::vector<float> target_stiffness;
   std::vector<float> target_damping;

   std::vector<float> previous_inertia;
   std::vector<float> previous_stiffness;
   std::vector<float> previous_damping;
   
   std::vector<float> current_position;              // last reported joint position
   std::vector<float> current_velocity;              // last estimated joint velocity
   std::vector<float> current_torque;                // last reported joint torque

   std::vector<float> previous_position;
   std::vector<float> previous_velocity;
   
   std::vector<float> position_error;
   std::vector<float> velocity_error;
   
   std::vector<float> motor_temperature;
   std::vector<float> motor_current;
   std::vector<float> motor_current_limit;

   std::vector<bool> motor_temp_bit_fault;
   std::vector<bool> motor_volt_bit_fault;
   std::vector<bool> motor_current_bit_fault;
   std::vector<bool> other_bit_fault;
   std::vector<bool> comms_timeout_fault;
   std::vector<unsigned int> comms_timeout_count;

   std::vector<RAD::BITStatus> bit_status;

   std::vector<RAD::SWState> current_sw_state;
   std::vector<RAD::FOCState> foc_state;

   std::vector<float> bus_voltage;
   std::vector<float> bus_current;

   std::vector<bool> waiting_for_impedance_ack;
   std::vector<bool> joint_reset_sent;
   std::vector<bool> joint_reset_recv;
   bool reset_flag;

   bool all_controllable;
   bool all_supplied;
   bool comms_status;   // true: CAN bus errors have not occurred, false: lost communication over bus
   
   
   // these values get copied out of the params object pass in to the initialize function
   unsigned int num_joints;
   std::vector<float> min_position_limit;              // minimum valid joint angle
   std::vector<float> max_position_limit;              // maximum valid joint angle
   std::vector<float> velocity_limit;                  // abs(maximum joint velocity)
   std::vector<float> acceleration_limit;              // abs(maximum joint acceleration)
   
   // these circular queues are used to filter the joint velocity computation
   //std::vector<CircularSumQueue> velocity_history;
   
};

#endif
