// BEGIN_QNA_COPYRIGHT
// END_QNA_COPYRIGHT

// BEGIN_QNA_FILE_INFO
// END_QNA_FILE_INFO

///////////////////////////////////////////////////////////
//  ManipulatorError.h
//  Enumeration of manipulator errors
//  Created on:      12-Dec-2008
//  Original author: mcsencsits
//  Last Updated:    22-July-2011 by mcsencsits
///////////////////////////////////////////////////////////


#if !defined(_MANIPULATOR_ERROR_INCLUDED_)
#define _MANIPULATOR_ERROR_INCLUDED_

#include "InterfaceType.h"

class ManipulatorError : public InterfaceType<unsigned char>
{
public:
   static ManipulatorError NO_ERROR();

   static ManipulatorError POSITION_LIMIT_REACHED();
   static ManipulatorError POSITION_LIMIT_VIOLATION();
   static ManipulatorError VELOCITY_LIMIT_REACHED();
   static ManipulatorError VELOCITY_LIMIT_VIOLATION();
   static ManipulatorError ACCELERATION_LIMIT_REACHED();
   static ManipulatorError ACCELERATION_LIMIT_VIOLATION();
   static ManipulatorError TORQUE_LIMIT_REACHED();
   static ManipulatorError TORQUE_LIMIT_VIOLATION();

   static ManipulatorError PARAM_FILE_INVALID();
   static ManipulatorError PARAM_FILE_INVALID_COUNT();
   static ManipulatorError PARAM_FILE_INVALID_JOINTS();
   static ManipulatorError PARAM_FILE_INVALID_DH();
   static ManipulatorError PARAM_FILE_INVALID_POSLIMITS();
   static ManipulatorError PARAM_FILE_INVALID_STOW();
   static ManipulatorError PARAM_FILE_INVALID_VELOCITY();
   static ManipulatorError PARAM_FILE_INVALID_ACCELERATION();
   static ManipulatorError PARAM_FILE_INVALID_RESOLUTION();
   static ManipulatorError PARAM_FILE_INVALID_ENC();
   static ManipulatorError PARAM_FILE_NOT_FOUND();

   static ManipulatorError PARAMETERS_NOT_INITIALIZED();
   static ManipulatorError PARAMETERS_NOT_KNOWN();

   static ManipulatorError INVALID_INDEX();

   static ManipulatorError CALIBRATION_FAILURE();
   static ManipulatorError JOINT_NOT_CALIBRATED();

   static ManipulatorError NO_IMPLEMENTATION();

   static ManipulatorError NO_COMMUNICATION();
   static ManipulatorError NO_FEEDBACK();

   static ManipulatorError INTERFACE_NOT_INITIALIZED();

   static ManipulatorError SET_VOLTAGE_ERROR();
   static ManipulatorError GET_VOLTAGE_ERROR();

   static ManipulatorError CONTROL_ERROR();
   static ManipulatorError RESET_ERROR();
   static ManipulatorError VALUE_OUT_OF_RANGE();

private:
   explicit ManipulatorError(unsigned char err_num, std::string str);
};


#endif // !defined(_MANIPULATOR_ERROR_INCLUDED_)
