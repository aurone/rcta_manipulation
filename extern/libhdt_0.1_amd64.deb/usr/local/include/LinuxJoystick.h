// BEGIN_QNA_COPYRIGHT
// END_QNA_COPYRIGHT
// BEGIN_QNA_FILE_INFO

// LinuxJoystick.h: <file description>
// Created June 1, 2011 by mcsencsits
// Updated  Nov 2, 2012 by mcsencsits

// END_QNA_FILE_INFO

#ifndef __LINUX_JOYSTICK_INCLUDED__
#define __LINUX_JOYSTICK_INCLUDED__

#include <string>
#include <linux/joystick.h>

/**
 * \brief Provides a simplified interface to a joystick/gamepad via the Linux joystick driver.
 *
 * This class wraps the Linux joystick driver in a way that enables a developer to implement
 * a simple loop which polls for the latest status of buttons and axes through a simple API.
 *
 * The expected usage of this class would look something like:
 *
 *     LinuxJoystick joy;
 *     if (joy.Initialize("/dev/input/js0"))
 *     {
 *        while (true)
 *        {
 *           joy.Update(); // parses the latest events
 *
 *           // do stuff based on state of buttons and axes
 *
 *           joy.ClearButtons(); // you could also move this to just before joy.Update()
 *        }
 *     }
 *
 */
class LinuxJoystick
{
public:

   /**
    * \brief Constructor
    *
    * \brief This doesn't do much
    */
   LinuxJoystick();

   /**
    * \brief Destructor
    *
    * This will free a few arrays if the instance successfully initialized.
    */
   ~LinuxJoystick();

   /**
    * \brief Initialize the joystick using an integer identifier
    * \param[in] joy_num Integer value of desired joystick to access.  This value is appended to
    *                    the string "/dev/input/js" to form the path which will be read.
    * \return true: joystick was successfully initialized and its state can be queried.
    *         false: joystick failed to open.
    */
   bool Initialize(unsigned int joy_num = 0);

   /**
    * \brief Initialize the joystick at the given path
    * \param[in] joy_path A std::string representing the path to the desired joystick to access.
    * \return true: joystick was successfully initialized and its state can be queried.
    *         false: joystick failed to open.
    */
   bool Initialize(const std::string & joy_path);

   /**
    * \brief Update the internal state of the joystick buttons and axes.
    *
    * This method must be called before Button, Axis, PressedButton, or Released Button and beginning
    * any section of code in which you want to know the latest state of the joystick.
    */
   void Update();

   /**
    * \brief Clear current 'pressed' and 'released' state of each button.
    *
    * This method should be called after the state of the joystick is finished being read each iteration.
    * Failing to call this method before the next call to Update() will result in any buttons which were
    * determined to have been 'pressed' or 'released' to maintain that state.  Meaning:
    *     LinuxJoystick joy;
    *     joy.Initialize();
    *     joy.Update();
    *     // axes at zero, no buttons have been pressed by operator
    *     // so Button(n) returns false, PressedButton(n) returns false, ReleasedButton(n) return false
    *     joy.ClearButtons();
    *     // operator presses and holds button 0
    *     joy.Update();
    *     // Button(0) returns true, PressedButton(0) returns true, ReleasedButton(0) returns false
    *     joy.ClearButtons();
    *     // operator released button 0
    *     joy.Update();
    *     // Button(0) returns false, PressedButton(0) returns false, ReleasedButton(0) returns true;
    *     joy.ClearButtons();
    *     // operator pressed and released button 0
    *     joy.Update();
    *     // Button() returns false, PressedButton(0) returns true, ReleasedButton(0) returns true
    *     // fail to call joy.ClearButtons()
    *     // operator presses and holds button 0
    *     joy.Update();
    *     // Button() returns true, PressedButton() returns true, ReleasedButton(0) return true (but this is old data)
    */
   void ClearButtons();

   /**
    * \brief Access last reported state of button indicated by index.
    * \param[in] index Index of desired button [0, NumButtons()-1]
    * \return true: last state of button was pressed/on/down
    *         false: last state of button was not pressed/off/up
    *
    * If index >= NumButtons() then false will be returned.
    */
   bool Button(unsigned int index) const;

   /**
    * \brief Determine whether a rising-edge occurred between the last two calls to Update().
    * \param[in] index Index of desired button [0, NumButtons()-1]
    * \return true: The state of the button changed from 'not pressed' to 'pressed' between the last
    *               two calls to Update()
    *         false: The state of the button did not change from 'not pressed' to 'pressed' between
    *                the last two calls to Update()
    */
   bool PressedButton(unsigned int index) const;

   /**
    * \brief Determine whether a falling-edge occurred between the last two calls to Update().
    * \param[in] index Index of desired button [0, NumButtons()-1]
    * \return true: The state of the button changed from 'pressed' to 'not pressed' between the last
    *               two calls to Update()
    *         false: The state of the button did not change from 'pressed' to 'not pressed' between
    *                the last two calls to Update()
    */
   bool ReleasedButton(unsigned int index) const;

   /**
    * \brief Access latest position of joystick axis.
    * \param[in] index Index of desired axis [0, NumAxes()-1]
    * \param[in] db Dead-band to apply to joystick axis [0.0, 1.0)
    * \return Floating-point value in the range [-1.0, 1.0] representing the joystick position
    *         along the desired axis.
    *
    * Returning a normalized axis position in the range [-1.0, 1.0] enables the developer to
    * quickly apply non-linear mappings if desired. (i.e. x_ax = pow(joy.Axis(1), 2.0) * MAX_VAL)
    */
   float Axis(unsigned int index, float db = 0.0) const;

   /**
    * \brief The number of axes available on the joystick/gamepad.
    */
   unsigned int NumAxes() const;

   /**
    * \brief The number of buttons on the joystick/gamepad.
    */
   unsigned int NumButtons() const;

   /**
    * \brief Get the manufacturer's name of the joystick
    * \param[in] name A std::string to copy the name into.
    */
   void GetName(std::string &name) const;

   /**
    * \brief Get the manufacturer's name of the joystick
    * \return A std::string containing the name of the joystick.
    *
    * Ex: "Microsoft X-Box 360 pad"
    */
   std::string Name() const;

   /**
    * \brief Get the path used to read the joystick
    * \return A std::string containing the path to the joystick
    *
    * Ex: "/dev/input/js0"
    */
   std::string Path() const;

private:

   std::string _joy_path;
   int _joy_fd;

   struct js_event _js;

   int _num_axes;
   int _num_buttons;
   char _joy_name[80];

   int *_axis;
   char *_button;


   char *_button_prev;
   char *_pressed_button;
   char *_released_button;

   void HandleButtons();
   bool Open();
};

#endif // __LINUX_JOYSTICK_INCLUDED__

