// BEGIN_QNA_COPYRIGHT
// END_QNA_COPYRIGHT
// BEGIN_QNA_FILE_INFO

// CANMessage.cpp: <file description>
// Created Sep 21, 2012 by mcsencsits
// Updated Sep 24, 2012 by mcsencsits

// END_QNA_FILE_INFO

#ifndef CANMESSAGE_H_
#define CANMESSAGE_H_

#include <RADMessages.h>
#include <stdint.h>

namespace HDT{

class CANMessage{
public:
   CANMessage();

   CANMessage& Destination(RAD::NodeID joint);
   RAD::NodeID Destination() const;

   CANMessage& Source(RAD::NodeID joint);
   RAD::NodeID Source() const;

   CANMessage& MessageID(RAD::MessageID msg); // This is only public to enable testing, the method is called for you when setting the payload
   RAD::MessageID MessageID() const;
   uint8_t Length() const;

   CANMessage& StatusRequestCmd(void);

   CANMessage& NodeResetCmd(RAD::NodeResetCmdPayload pl);
   RAD::NodeResetCmdPayload const& NodeResetCmd() const;

   CANMessage& ChangeModeCmd(RAD::ChangeModeCmdPayload pl);
   RAD::ChangeModeCmdPayload const& ChangeModeCmd() const;

   CANMessage& ControlCmd(RAD::ControlCmdPayload pl);
   RAD::ControlCmdPayload const& ControlCmd() const;

   CANMessage& ImpedanceCmd(RAD::ImpedanceCmdPayload pl);
   RAD::ImpedanceCmdPayload const& ImpedanceCmd() const;

   RAD::BITErrorMsgPayload const& BITErrorMsg() const;
   RAD::HsTelemetryMsgPayload const& HsTelemetryMsg() const;
   RAD::LsTelemetryMsgPayload const& LsTelemetryMsg() const;
   RAD::StatusMsgPayload const& StatusMsg() const;
   RAD::AckMsgPayload const& AckMsg() const;
   RAD::NackMsgPayload const& NackMsg() const;


protected:
   union{
      uint32_t id;            // can-id
      struct {
         uint8_t spare:3;
         uint8_t frame_type:3;
         uint8_t frame_seq:6;
         uint8_t src_id:6;
         uint8_t dst_id:4;
         uint8_t msg_id:7;
         uint8_t ext_id_flag:1;
         uint8_t event_flag:1;
         uint8_t res:1;
      } __attribute__((__packed__));
   };
   uint8_t  len;           // length of message: 0-8 bytes
   uint8_t  msg_lost;      // count of lost rx-messages
   uint8_t  reserved[2];   // reserved
   uint8_t  data[8];       // 8 data-bytes

} __attribute__((__packed__));

}

#endif /* CANMESSAGE_H_ */
