#ifndef JAUS_BASE_H
#define JAUS_BASE_H
/**
 *
 * \file jaus_base.h
 *
 * THIS WORK CONTAINS VALUABLE CONFIDENTIAL AND PROPRIETARY INFORMATION.
 * DISCLOSURE OR REPRODUCTION WITHOUT THE WRITTEN AUTHORIZATION OF Applied
 * Perception IS PROHIBITED. THIS UNPUBLISHED WORK BY Applied Perception
 * IS PROTECTED BY THE LAWS OF THE UNITED STATES AND OTHER
 * COUNTRIES. IF PUBLICATION OF THE WORK SHOULD OCCUR, THE FOLLOWING NOTICE
 * SHALL APPLY.
 *
 * "COPYRIGHT (C) 2003 Applied Perception ALL RIGHTS RESERVED."
 *
 * Applied Perception DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL Applied Perception BE LIABLE FOR ANY SPECIAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 *
 * THE USER'S RIGHTS TO USE, MODIFY, REPRODUCE, RELEASE, PERFORM, DISPLAY,
 * OR DISCLOSE THE TECHNICAL DATA AND COMPUTER SOFTWARE IN THIS FILE IS
 * RESTRICTED BY THE Applied Perception LICENSE AGREEMENT PROVIDED WITH
 * DELIVERY OF THIS FILE. ANY REPRODUCTION OF TECHNICAL DATA, COMPUTER
 * SOFTWARE, OR PORTIONS THEREOF MARKED WITH THIS LEGEND MUST ALSO
 *

 **/

#include <jaus_includes.h>

#ifdef JAUS_BASE_LOG4CXX
#include "log4cxx/logger.h"
#endif

/********** JAUS SPECIFICATION NUMBER **********/
#define JLIB_JAUS_SPEC                                      3.0

/* Build for OPC 2.75 code */
#define OPC_275

/* Default component attributes */
#define JLIB_MIN_MESSAGE_ARRAY_SIZE                 32
#define JLIB_DEFAULT_MESSAGE_ARRAY_SIZE             128
#define JLIB_MAX_MESSAGE_ARRAY_SIZE                 256
#define JLIB_SHARED_MEMORY                          1
#define JLIB_SERIAL_LINE                            2
#define JLIB_TCP                                    3
#define JLIB_UDP                                    4
#define JLIB_UNIX_SOCKET                            5
#define JLIB_LOCAL_SOCKET                           6
#define JLIB_MAX_TRANSPORT_MODE                     JLIB_LOCAL_SOCKET
#define JLIB_DEFAULT_CONNECTON_MODE                 JLIB_SHARED_MEMORY
#define JLIB_DEFAULT_SERIAL_LINE_SPEED              115200L
#define JLIB_DEFAULT_ACK_NAK_USE                    JLIB_JAUS_NO_ACK_REQUIRED
#define JLIB_DEFAULT_BLOCK_ON_SEND                  BLOCK
#define JLIB_MIN_AUTHORITY                          0
#define JLIB_DEFAULT_AUTHORITY                      0
#define JLIB_MAX_AUTHORITY                          255
#define JLIB_DEFAULT_POST_EMERGENCY_STATE           JLIB_JAUS_STATE_STANDBY
#ifdef __Rabbit
#define JLIB_DEFAULT_SERVICE_CONNECTION_INTERVAL   0.1 /* 10 Hz */
#else
#define JLIB_DEFAULT_SERVICE_CONNECTION_INTERVAL   0.05 /* 20 Hz */
#endif

#ifdef __Rabbit
#define JLIB_MAX_COMPONENTS_PER_PROCESS      1
#define JLIB_COMMAND_CODE_MAPPING_ARRAY_SIZE 32
#else
#ifndef JLIB_MAX_COMPONENTS_PER_PROCESS
/* If not defined in build env, set a reasonable default. */
#define JLIB_MAX_COMPONENTS_PER_PROCESS      10
#endif
#define JLIB_COMMAND_CODE_MAPPING_ARRAY_SIZE 1024
#endif

/* Service connection constants. */
#ifdef __Rabbit
#define JLIB_MAX_SERVICE_CONNECTIONS       4
#else
#define JLIB_MAX_SERVICE_CONNECTIONS       255
#endif
#define JLIB_SERVICE_CONNECTION_TERMINATED 0
#define JLIB_SERVICE_CONNECTION_ACTIVE     1
#define JLIB_SERVICE_CONNECTION_SUSPENDED  2

#define JLIB_SERVICE_CONNECTION_THREAD_NOT_STARTED        0
#define JLIB_SERVICE_CONNECTION_THREAD_STARTED            1
#define JLIB_SERVICE_CONNECTION_THREAD_ERROR              2


/* Generic constants. */
#define JLIB_TRUE                                         1
#define JLIB_FALSE                                        0

/* Shared memory naming constants */
/* NOTE: platform-dependent prefixes have moved to config.h */
#define JLIB_SHARED_MEMORY_NODE_MGR_COMPONENT_BASE_NAME "_001_001"

/* Unix socket naming constants */
/* NOTE: platform-dependent prefixes have moved to config.h */
#define JLIB_UNIX_SOCKET_NODE_MGR_COMPONENT_BASE_NAME "_001_001"

/* Local Socket Port constants */
#define JLIB_LOCAL_SOCKET_BASE_PORT_NUMBER            20000

/* Constants to use for converting to and from reals to various JAUS data
   types. These are to be used as the type_max parameter to the following
   macros. The type names are from limits.h */
#if defined(__Rabbit)
#define JLIB_BOOL             unsigned char /* 1 byte */
#define JLIB_BYTE             char /* 1 byte */
#define JLIB_UBYTE            unsigned char
#define JLIB_SHORT            int  /* 2 bytes */
#define JLIB_USHORT           unsigned int
#define JLIB_INT              long /* 4 bytes */
#define JLIB_UINT             unsigned long
#define JLIB_LONG             long /* 4 bytes */
#define JLIB_ULONG            unsigned long /* 4 bytes */
#define JLIB_FLOAT            float  /* 4 bytes */
#define JLIB_DOUBLE           double /* ALSO 4 bytes (not 8) */
#elif defined(LINUX) || defined(QNX) || defined(_WIN32_WCE) || defined(BSD) || defined(CYGWIN) || defined(WIN32)
#define JLIB_BOOL             unsigned char /* 1 byte */
#define JLIB_BYTE             char   /* 1 byte */
#define JLIB_UBYTE            unsigned char
#define JLIB_SHORT            short  /* 2 bytes */
#define JLIB_USHORT           unsigned short
#define JLIB_INT              int    /* 4 bytes */
#define JLIB_UINT             unsigned int
#define JLIB_LONG             int64_t /* 8 bytes */
#define JLIB_ULONG            uint64_t /* 8 bytes */
/* #define JLIB_LONG             long /\* 8 bytes *\/ */
/* #define JLIB_ULONG            unsigned long /\* 8 bytes *\/ */
#define JLIB_FLOAT            float  /* 4 bytes */
#define JLIB_DOUBLE           double /* 8 bytes */
#else
#error One of LINUX | QNX | _WIN32_WCE | BSD | CYGWIN is not defined.  Check configure.ac
#endif

#ifdef WIN32
// Need some fixups for WIN32.
#undef JLIB_LONG
#define JLIB_LONG             long long /* 8 bytes */
#undef JLIB_ULONG
#define JLIB_ULONG            unsigned long long /* 8 bytes */
// Provide some defines we use from C99 inttypes.h
#ifndef OTHERS_HAVE_STD_INT
#define int8_t                char   /* 1 byte */
#define uint8_t               unsigned char
#define int16_t               short  /* 2 bytes */
#define uint16_t              unsigned short
#define int32_t               int    /* 4 bytes */
#define uint32_t              unsigned int
#define int64_t               long long/* 8 bytes */
#define uint64_t              unsigned long long /* 8 bytes */
#endif
#endif

/* Some linux limits.h don't define LLONG_* unless __USE_ISOC99 is defined,
 * but not sure what else __USE_ISOC99 would affect.  So just jam these here.
 */
# ifndef LLONG_MAX
#  define LLONG_MAX	__LONG_LONG_MAX__
# endif
# ifndef LLONG_MIN
#  define LLONG_MIN	(-LLONG_MAX-1)
# endif
# ifndef ULLONG_MAX
#  define ULLONG_MAX	(LLONG_MAX * 2ULL + 1)
# endif


#define JLIB_CONVERT_BYTE     (127)             /* 2^7 - 1 SCHAR_MAX */
#define JLIB_CONVERT_SHORT    (32767)           /* 2^15 - 1 SHRT_MAX */
#define JLIB_CONVERT_INT      (2147483647L)      /* 2^31 - 1 LONG_MAX*/
#define JLIB_CONVERT_LONG     (9223372036854775807L) /* 2^64 - 1 LLONG_MAX) */

#define JLIB_CONVERT_UBYTE    (255)             /* 2^8 - 1 UCHAR_MAX */
#define JLIB_CONVERT_USHORT   (65535)           /* 2^16 - 1 USHRT_MAX */
#define JLIB_CONVERT_UINT     (4294967295U)      /* 2^32 - 1 ULONG_MAX */
#define JLIB_CONVERT_ULONG    (18446744073709551615U) /* 2^64 -1 ULLONG_MAX */

#if defined(__cplusplus) && ! defined(_DEBUG)
#define JAUS_BASE_INLINE inline
#else
#define JAUS_BASE_INLINE
#endif
#ifdef WIN32
static JAUS_BASE_INLINE double rint(double s)
{
  int i;
  double s2;
  double s3;

  i = (int)s;
  s2 = (double)i;

  s3 = s2 - s;

  if (s3 >= 0.5)
    s2 = s2 + 1;
  else
    s2 = s2;

  return s2;
}

/* Define a macro for string uncased comparisons */
#define strcasecmp _stricmp
#endif
/* Macros to convert to and from reals from various JAUS data types. */
#define JLIB_CONVERT_UNSIGNED_TO_REAL(type_max, s, min, max)            \
  ((((JLIB_DOUBLE) (s)) * ((JLIB_DOUBLE) (max) - (JLIB_DOUBLE) (min))) / ((JLIB_DOUBLE) (type_max)) + (JLIB_DOUBLE) (min))

#define JLIB_CONVERT_SIGNED_TO_REAL(type_max, s, min, max)              \
  ((((JLIB_DOUBLE) s) / 2.0 * (max - min)) / ((JLIB_DOUBLE) type_max) + (max + min) / 2.0)

#define JLIB_CONVERT_REAL_TO_UNSIGNED(type_max, d, min, max)            \
  (unsigned) (rint((d - min) * ((JLIB_DOUBLE) type_max) / (max - min)))

#define JLIB_CONVERT_REAL_TO_SIGNED(type_max, d, min, max)              \
  (signed) (rint((d - (max + min) / 2.0) * 2.0 * type_max / (max - min)))

/* Macros to swap bytes on big endian machines - JAUS is little endian. */
#if defined(BENDIAN)
#define JLIB_SWAP_16(arg)        ((((arg) >> 8) & 0xff) |       \
                                  (((arg) & 0xff) << 8))
#define JLIB_SWAP_32(arg)   		((((arg) >> 24) & 0xff) |       \
                                         (((arg) >> 8) & 0xff00) |      \
                                         (((arg) & 0xff00) << 8) |      \
                                         (((arg) & 0xff) << 24))
#define JLIB_SWAP_64(arg)        ((((arg) >> 56) & 0xff) |              \
                                  (((arg) >> 40) & 0xff00) |            \
                                  (((arg) >> 24) & 0xff0000) |          \
                                  (((arg) >>  8) & 0xff000000) |        \
                                  (((arg) & 0xff000000) <<  8) |        \
                                  (((arg) & 0xff0000) << 24) |          \
                                  (((arg) & 0xff00) << 40) |            \
                                  (((arg) & 0xff) << 56))
#elif defined (LENDIAN)
#define JLIB_SWAP_16(arg)         arg
#define JLIB_SWAP_32(arg)         arg
#define JLIB_SWAP_64(arg)         arg
#else
#error BYTE_ORDER not defined
#endif

/* Macros to pack and unpack shorts and ints. */
#if defined(__ALIGN_32)

// removes issue with TS-7300 ARM9 word alignment
#define JLIB_PACK_SHORT(s, buf)   { JLIB_SHORT __s;  __s = JLIB_SWAP_16(s); \
    memcpy(buf, &__s, sizeof(JLIB_SHORT)); }
#define JLIB_PACK_USHORT(us, buf) { JLIB_USHORT __us;  __us = JLIB_SWAP_16(us); \
    memcpy(buf, &__us, sizeof(JLIB_USHORT)); }
#define JLIB_PACK_INT(i, buf)     { JLIB_INT __i;  __i = JLIB_SWAP_32(i); \
    memcpy(buf, &__i, sizeof(JLIB_INT)); }
#define JLIB_PACK_UINT(ui, buf)   { JLIB_UINT __ui;  __ui = JLIB_SWAP_32(ui); \
    memcpy(buf, &__ui, sizeof(JLIB_UINT)); }
#define JLIB_PACK_FLOAT(f, buf)   { JLIB_FLOAT __f;  __f = JLIB_SWAP_32(f); \
    memcpy(buf, &__f, sizeof(JLIB_FLOAT)); }
#define JLIB_PACK_LONG(l, buf)    { JLIB_LONG __l; __l = JLIB_SWAP_64(l); \
    memcpy(buf, &__l, sizeof(JLIB_LONG)); }
#define JLIB_PACK_ULONG(ul, buf)  { JLIB_LONG __ul; __ul = JLIB_SWAP_64(ul); \
    memcpy(buf, &__ul, sizeof(JLIB_ULONG)); }
#define JLIB_PACK_DOUBLE(lf, buf)  { JLIB_LONG __lf; __lf = JLIB_SWAP_64(lf); \
    memcpy(buf, &__lf, sizeof(JLIB_DOUBLE)); }
#else
#define JLIB_PACK_SHORT(s, buf)     (*((JLIB_SHORT *) buf) = JLIB_SWAP_16(s))
#define JLIB_PACK_USHORT(us, buf)   (*((JLIB_USHORT *) buf) = JLIB_SWAP_16(us))
#define JLIB_PACK_INT(i, buf)       (*((JLIB_INT *) buf) = JLIB_SWAP_32(i))
#define JLIB_PACK_UINT(ui, buf)     (*((JLIB_UINT *) buf) = JLIB_SWAP_32(ui))
#define JLIB_PACK_FLOAT(f, buf)     (*((JLIB_FLOAT *) buf) = JLIB_SWAP_32(f))
#ifdef __Rabbit
#define JLIB_PACK_LONG(l, buf)      (*((JLIB_LONG *) buf) = JLIB_SWAP_32(l))
#define JLIB_PACK_ULONG(ul, buf)    (*((JLIB_ULONG *) buf) = JLIB_SWAP_32(ul))
#define JLIB_PACK_DOUBLE(f, buf)    (*((JLIB_DOUBLE *) buf) = JLIB_SWAP_32(ui))
#else
#define JLIB_PACK_LONG(l, buf)      (*((JLIB_LONG *) buf) = JLIB_SWAP_64(l))
#define JLIB_PACK_ULONG(ul, buf)    (*((JLIB_ULONG *) buf) = JLIB_SWAP_64(ul))
#define JLIB_PACK_DOUBLE(lf, buf)    (*((JLIB_DOUBLE *) buf) = JLIB_SWAP_64(lf))
#endif /* ! defined (__Rabbit) */
#endif /* ! defined(__ALIGN_32) */

#define JLIB_PACK_RGB(val, buf)     ((JLIB_UBYTE *)buf)[0] = val.r;     \
  ((JLIB_UBYTE *)buf)[1] = val.g;                                       \
  ((JLIB_UBYTE *)buf)[2] = val.b;
#define JLIB_PACK_RGBA(val, buf)    ((JLIB_UBYTE *)buf)[0] = val.r;     \
  ((JLIB_UBYTE *)buf)[1] = val.g;                                       \
  ((JLIB_UBYTE *)buf)[2] = val.b;                                       \
  ((JLIB_UBYTE *)buf)[3] = val.a;

#if defined(__ALIGN_32)

// removes issue with TS-7300 ARM9 word alignment
#define JLIB_UNPACK_SHORT(s, buf)   { JLIB_SHORT __s;   \
    memcpy(&__s, buf, sizeof(JLIB_SHORT));              \
    s = JLIB_SWAP_16(__s); }
#define JLIB_UNPACK_USHORT(us, buf) { JLIB_USHORT __us; \
    memcpy(&__us, buf, sizeof(JLIB_USHORT));            \
    us = JLIB_SWAP_16(__us); }
#define JLIB_UNPACK_INT(i, buf)     { JLIB_INT __i;     \
    memcpy(&__i, buf, sizeof(JLIB_INT));                \
    i = JLIB_SWAP_32(__i); }
#define JLIB_UNPACK_UINT(ui, buf)   { JLIB_UINT __ui;   \
    memcpy(&__ui, buf, sizeof(JLIB_UINT));              \
    ui = JLIB_SWAP_32(__ui); }
#define JLIB_UNPACK_FLOAT(f, buf)   { JLIB_FLOAT __f;   \
    memcpy(&__f, buf, sizeof(JLIB_FLOAT));              \
    f = JLIB_SWAP_32(__f); }
#define JLIB_UNPACK_LONG(l, buf)    { JLIB_LONG __l;    \
    memcpy(&__l, buf, sizeof(JLIB_LONG));               \
    l = JLIB_SWAP_32(__l); }
#define JLIB_UNPACK_ULONG(ul, buf)  { JLIB_LONG __ul;   \
    memcpy(&__ul, buf, sizeof(JLIB_ULONG));             \
    ul = JLIB_SWAP_32(__ul); }
#define JLIB_UNPACK_DOUBLE(lf, buf) { JLIB_LONG __lf;   \
    memcpy(&__lf, buf, sizeof(JLIB_DOUBLE));            \
    lf = JLIB_SWAP_32(__lf); }
#else
#define JLIB_UNPACK_SHORT(s, buf)   (s = JLIB_SWAP_16(*((JLIB_SHORT *) buf)))
#define JLIB_UNPACK_USHORT(us, buf) (us = JLIB_SWAP_16(*((JLIB_USHORT *) buf)))
#define JLIB_UNPACK_INT(i, buf)     (i = JLIB_SWAP_32(*((JLIB_INT *) buf)))
#define JLIB_UNPACK_UINT(ui, buf)   (ui = JLIB_SWAP_32(*((JLIB_UINT *) buf)))
#define JLIB_UNPACK_FLOAT(f, buf)   (f = JLIB_SWAP_32(*((JLIB_FLOAT *) buf)))
#ifdef __Rabbit
#define JLIB_UNPACK_LONG(l, buf)    (l = JLIB_SWAP_32(*((JLIB_LONG *) buf)))
#define JLIB_UNPACK_ULONG(ul, buf)  (ul = JLIB_SWAP_32(*((JLIB_ULONG *) buf)))
#define JLIB_UNPACK_DOUBLE(lf, buf)  (lf = JLIB_SWAP_32(*((JLIB_DOUBLE *) buf)))
#else
#define JLIB_UNPACK_LONG(l, buf)    (l = JLIB_SWAP_64(*((JLIB_LONG *) buf)))
#define JLIB_UNPACK_ULONG(ul, buf)  (ul = JLIB_SWAP_64(*((JLIB_ULONG *) buf)))
#define JLIB_UNPACK_DOUBLE(lf, buf)  (lf = JLIB_SWAP_64(*((JLIB_DOUBLE *) buf)))
#endif /* ! defined (__Rabbit) */
#endif /* ! defined(__ALIGN_32) */

#define JLIB_UNPACK_RGB(val, buf)   val.r = ((JLIB_UBYTE *)buf)[0];     \
  val.g = ((JLIB_UBYTE *)buf)[1];                                       \
  val.b = ((JLIB_UBYTE *)buf)[2];
#define JLIB_UNPACK_RGBA(val, buf)  val.r = ((JLIB_UBYTE *)buf)[0];     \
  val.g = ((JLIB_UBYTE *)buf)[1];                                       \
  val.b = ((JLIB_UBYTE *)buf)[2];                                       \
  val.a = ((JLIB_UBYTE *)buf)[3];

/* data type sizes, in bytes */
#if defined(__Rabbit)
#define JLIB_BYTE_SIZE    1
#define JLIB_UBYTE_SIZE   1
#define JLIB_SHORT_SIZE   2
#define JLIB_USHORT_SIZE  2
#define JLIB_INT_SIZE     4
#define JLIB_UINT_SIZE    4
#define JLIB_LONG_SIZE    4
#define JLIB_ULONG_SIZE   4
#define JLIB_FLOAT_SIZE   4
#define JLIB_DOUBLE_SIZE  4
#elif defined(LINUX) || defined(QNX) || defined(_WIN32_WCE) || defined(BSD) || defined (CYGWIN) || defined (WIN32)
#define JLIB_BYTE_SIZE    1
#define JLIB_UBYTE_SIZE   1
#define JLIB_SHORT_SIZE   2
#define JLIB_USHORT_SIZE  2
#define JLIB_RGB_SIZE     3
#define JLIB_RGBA_SIZE    4
#define JLIB_INT_SIZE     4
#define JLIB_UINT_SIZE    4
#define JLIB_LONG_SIZE    8
#define JLIB_ULONG_SIZE   8
#define JLIB_FLOAT_SIZE   4
#define JLIB_DOUBLE_SIZE  8
#else
#error One of LINUX | QNX | _WIN32_WCE | BSD | CYGWIN is not defined.  Check configure.ac
#endif


/* In this version of TRUNC, TRUNC(-2.4) = -2 and TRUNC(2.4) = 2 */
#ifndef TRUNC
#define TRUNC(arg)             ((JLIB_FLOAT)(JLIB_INT)(arg))
#endif

/* Verbosity related constants. */
#define JLIB_PRINT_ALL                    255
#define JLIB_PRINT_MESSAGES               200
#define JLIB_PRINT_DEBUG4                 180
#define JLIB_PRINT_DEBUG3                 170
#define JLIB_PRINT_DEBUG2                 160
#define JLIB_PRINT_DEBUG1                 150
#define JLIB_PRINT_BASIC                  100
#define JLIB_PRINT_NEVER                  1
#define JLIB_PRINT_ALWAYS                 0

#ifndef M_PI
#define M_PI 3.14159235
#endif

#ifndef EOK
#define EOK 0
#endif

/* Common typedefs */
typedef JLIB_UINT jLib_jaus_id_t;

typedef JLIB_UBYTE jLib_subsystem_id_t;

typedef JLIB_UBYTE jLib_node_id_t;

typedef JLIB_UBYTE jLib_component_id_t;

typedef JLIB_UBYTE jLib_instance_id_t;

typedef struct {

  jLib_subsystem_id_t subsystem_id;
  jLib_node_id_t node_id;
  jLib_component_id_t component_id;
  jLib_instance_id_t instance_id;

} jLibComponentId_t;

/* Platform-dependent typedefs */
#ifdef SYSV5
/* System 5 specific */

/* This structure is used by SYSV5 semaphores to hold semaphore
   data. We assume that it is kept in shared memory, so that
   multiple processes have access to the key value */
typedef struct {
  /* Semaphore ID returned by semget, and used by other sem. functions */
  JLIB_INT semId;
  /* Unique key ID, which is used to refer to this semaphore. SYSV5
     only has the concept of named-semaphores. */
  JLIB_INT keyId;
} semaphore_t;

#endif

#ifdef POSIX
/* POSIX Specific */

/// The POSIX structure used to access semaphores.
typedef sem_t semaphore_t;
#endif

#ifdef CYGWIN
#typedef size_t socklen_t
#endif

#ifdef __Rabbit
/* Rabbit - placeholder - semaphores/shared memory not supported. */
typedef JLIB_INT semaphore_t;
#endif

#ifdef _WIN32_WCE
/* Windows - placeholder - semaphores/shared memory not supported. */
typedef DWORD semaphore_t;
#endif

#ifdef WIN32
/* Miscellaneous WIN-isms */
typedef int speed_t;
#define MSG_DONTWAIT	0
typedef SOCKET socket_t;
#else
typedef int socket_t;
#endif


/* prototypes */
#ifdef __cplusplus
extern "C" {
#endif

/* component globals */
#ifdef ALLOC_JAUS_BASE_GLOBALS
  JLIB_UBYTE jLibVerbosityLevelG = JLIB_PRINT_BASIC;
  FILE * jLibOutputFileG = NULL;
#else
  extern JLIB_UBYTE jLibVerbosityLevelG;
  extern FILE * jLibOutputFileG;
#endif

  void jLibOutputUserMessage( JLIB_UBYTE level, const JLIB_BYTE *format, ...);
  void jLibOutputNetworkErrorMessage(JLIB_UBYTE level, const JLIB_BYTE *message);
  void jLibSetLibraryVerbosityLevel(JLIB_UBYTE level);
  JLIB_UBYTE jLibGetLibraryVerbosityLevel(void);
  void jLibSetLibraryOutputFile(FILE *file);
  FILE * jLibGetLibraryOutputFile(void);

/** sem.c **/
  JLIB_INT getIndexFromSemaphore(semaphore_t *sem );
  JLIB_INT semaphoreInit( semaphore_t *sem, JLIB_INT shared, JLIB_INT value );
  JLIB_INT semaphorePost( semaphore_t *sem );
  JLIB_INT semaphoreWait( semaphore_t *sem );
  JLIB_INT semaphoreTryWait( semaphore_t *sem );
  JLIB_INT semaphoreDestroy( semaphore_t *sem );

/** utils.c **/
  JLIB_DOUBLE jLibGetProcessTime(void);
#ifdef __cplusplus
}

#ifdef JAUS_BASE_LOG4CXX
#ifdef ALLOC_JAUS_BASE_GLOBALS
#ifdef LINUX
// Bug in APR initialization causes segfault in releaseRef
// on termination.  This is a hack for log4cxx 0.10.0.
log4cxx::LoggerPtr jLibLoggerG((log4cxx::Logger::getLogger("Qna.BaseJaus")));
bool jLibLoggerInitializedG = true;
#else
// Otherwise we'll initialize explicitly in code.
log4cxx::LoggerPtr jLibLoggerG;
bool jLibLoggerInitializedG = false;
#endif
#else
extern log4cxx::LoggerPtr jLibLoggerG;
extern bool jLibLoggerInitializedG;
#endif

/*!
 * \brief Set default logger configuration for runtime.
 *
 *  default logger = "Qna.BaseJaus"
 *  default threshold = TRACE
 *  additivity = false  (don't call ancestor appenders)
 *  layout = "%d [%t] %-5p %c - %m%n"
 */
void jLibInitializeLogging( void );

/*!
 * \brief Set the per-process default BASE_JAUS logger.
 *
 *  \param logger a configured logger
 */
void jLibSetLogger( log4cxx::LoggerPtr logger );

/*!
 * \brief Get the per-process default BASE_JAUS logger.
 *
 * If this function is called before the first call to any
 * of the following, it will return NULL.
 *
 * \c jLibConfigureDefaultLogger()
 * \c jLibOutputUserMessage()
 * \c jLibOutputNetworkErrorMessage()
 *
 * \returns pointer to the current configured logger.
 */
log4cxx::LoggerPtr jLibGetLogger( void );

/*!
 * \brief Transitional version of jLibOutputUserMessage.
 *
 * Allows users to change jLibOutputUserMessage() to point to
 * new loggers without having to modify the rest of the code.
 *
 * \param logger the desired logger
 * \param level
 * \param format printf format string
 * \param ... varargs for format
 */
void jLibOutputUserMessage( log4cxx::LoggerPtr logger,
                            JLIB_UBYTE level,
                            const JLIB_BYTE *format, ...);

/*!
 * \brief Transitional version of jLibOutputNetworkErrorMessage.
 *
 * Allows users to change jLibOutputNetworkErrorMessage() to point to
 * new loggers without having to modify the rest of the code.
 *
 * \param logger the desired logger
 * \param level
 * \param message string to prepend to the system error message string.
 */
void jLibOutputNetworkErrorMessage( log4cxx::LoggerPtr logger,
                                    JLIB_UBYTE level,
                                    const JLIB_BYTE *message);
#endif // JAUS_BASE_LOG4CXX
#endif // __cplusplus
#endif // JAUS_BASE_H
