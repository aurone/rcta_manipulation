#ifndef CLOCK_TOOLS_H
#define CLOCK_TOOLS_H
/**
 *
 * \file clock_tools.h
 *
 * Based on:
 * Id: tools.h,v 1.16 2007/03/13 18:11:01 jaus Exp
 * Revision: 1.16
 * Date: 2007/03/13 18:11:01
 *
 * THIS WORK CONTAINS VALUABLE CONFIDENTIAL AND PROPRIETARY INFORMATION.
 * DISCLOSURE OR REPRODUCTION WITHOUT THE WRITTEN AUTHORIZATION OF Applied
 * Perception IS PROHIBITED. THIS UNPUBLISHED WORK BY Applied Perception
 * IS PROTECTED BY THE LAWS OF THE UNITED STATES AND OTHER
 * COUNTRIES. IF PUBLICATION OF THE WORK SHOULD OCCUR, THE FOLLOWING NOTICE
 * SHALL APPLY.
 *
 * "COPYRIGHT (C) 2003 Applied Perception ALL RIGHTS RESERVED."
 *
 * Applied Perception DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL Applied Perception BE LIABLE FOR ANY SPECIAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 *
 **/

/*****************************************************************************/
/* General Constants */

#if defined(WIN32)
#include <winsock2.h> /* for timeval et al */
/* A inline Win32/64 implementation of gettimeofday provided in this component */
#include <msvc_timeval.h>
#else
#ifndef __USE_BSD
#define __USE_BSD		// for timeval convenience macros
#endif
#include <sys/time.h>
#endif

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#ifndef ON
#define ON   1
#define OFF  0
#endif

/*****************************************************************************/
/* clock tool macros used */
#define MILLION 1000000L
#define BILLION 1000000000L
#define EPSILON 0.000001

#if defined(WIN32)
// TODO: this fails w/ MSVC 8.0
// inline void usleep(unsigned long d) { Sleep (d/1000); }
#define usleep(tee) Sleep(tee/1000)
#define CURRENT_TIME(mytime) { union { long long ns100; FILETIME ft; } now; \
			       struct timeval p; \
                               GetSystemTimeAsFileTime(&(now.ft)); \
	                       p.tv_usec = (long)((now.ns100 / 10LL) % 1000000LL); \
                               p.tv_sec = (long)((now.ns100-(116444736000000000LL))/10000000LL); \
			       mytime = (double) (p.tv_sec) + (double)((p.tv_usec)/1000000.0); }

#define INTERVAL_TIME(time) { LARGE_INTEGER freq; QueryPerformanceFrequency(&freq); \
                              LARGE_INTEGER hrtime; QueryPerformanceCounter(&hrtime); \
                              time = (double)(hrtime.QuadPart) / (double)(freq.QuadPart); }
#else
#define CURRENT_TIME(time) { struct timeval _ct; gettimeofday(&_ct, NULL); \
                             time = (double) (_ct.tv_sec) + \
                                    (double) ((_ct.tv_usec) / 1000000.0) ;}

#define INTERVAL_TIME(time) CURRENT_TIME(time)
#endif

#define CONVERT_TIME(ct) ((double) (ct.tv_sec) +  \
                          (double) ((ct.tv_usec) / 1000000.0))

#define TV_TO_TIME(tv, time) { time = (double) (tv.tv_sec) + \
                                      (double) ((tv.tv_usec) / 1000000.0) ;}

#define TIME_TO_TV(time, tv) { tv.tv_sec = (long)(time); \
                               tv.tv_usec = (long)((time - (double)TRUNC(time))*1000000.0); }

#if 0
#define CURRENT_TIME(time) clock_gettime(CLOCK_REALTIME, &_current_time);\
                           time = (double) _current_time.tv_sec + \
                           ((double)_current_time.tv_nsec / BILLION);

#define FAST_CURRENT_TIME(time) clock_gettime(CLOCK_REALTIME, &_current_time);\
                           time = (100 * _current_time.tv_sec) + \
                           (_current_time.tv_nsec / 10000000L);
#endif


#define DELAY(secs)      usleep((long) (secs * ((double) MILLION)))
#define SLEEP(secs)      DELAY(secs)

#endif
