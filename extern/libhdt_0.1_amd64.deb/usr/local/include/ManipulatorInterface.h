// BEGIN_QNA_COPYRIGHT
// END_QNA_COPYRIGHT

// BEGIN_QNA_FILE_INFO
// END_QNA_FILE_INFO

///////////////////////////////////////////////////////////
//  ManipulatorInterface.h
//  Definition of the abstract Class ManipulatorInterface
//  Created on:      5-June-2009 3:15:00 PM
//  Original author: mcsencsits
//  Last Updated:    25-July-2011 by mcsencsits
///////////////////////////////////////////////////////////

#ifndef __MANIPULATOR_INTERFACE_INCLUDED__
#define __MANIPULATOR_INTERFACE_INCLUDED__

#include <vector>
#include <string>

#include <ManipulatorParameters.h>

/**
 * \brief Establishes the API for the manipulator hardware abstraction layer.
 */
class ManipulatorInterface{
    public:
        //ManipulatorInterface(const ManipulatorParameters &params);
        //virtual ~ManipulatorInterface(){}
        
        /**
         * \brief Initializes the interface based on a ManipulatorParameters instance.
         * \param[in] params Instance of ManipulatorParameters used to initialize ManipulatorInterface.  In the case of a simulator
         *                   this provides the number of joints to simulate as well as position/velocity/acceleration limits.  For 
         *                   interfaces to real manipulators this is most likely ignored.
         * \return ManipulatorError::NO_ERROR is returned on successful initialization of the interface.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not overide the base class implementation.\n
         *         ManipulatorError::PARAMETERS_NOT_INITIALIZED is returned if params has not been initialized and is needed.\n
         *         ManipulatorError::PARAMETERS_NOT_KNOWN is returned if the initialization method requires parameters that are not available in params.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if there is no responce from the manipulator during initialization.
         */
        virtual ManipulatorError initialize(const ManipulatorParameters & params);

        /**
         * \brief Returns bool indicating whether or not the interface has been initialized. 
         * \return true if the interface has been correctly initialized\n
         *         false if the interface has not been initialized
         */
        virtual bool isInitialized() const;
        
        /** \brief Returns unsigned int giving number of joints in the interface.
         *  \return Number of joints in the interface
         */
        virtual unsigned int getNumJoints() const;
         
        /**
         * \brief Copies the most current joint position value for the joint referenced by jointIndex into position. Units are in
         *         \f$radians\f$ for revolute joints and \f$meters\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] position Reference to memory where the current joint position value will be copied.
         * \return ManipulatorError::NO_ERROR is returned when the current joint position is successfully copied to position.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *          that the value in position has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *          cannot report an accurate reading of its position.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing position data is unavailable.\n
         *         ManipulatorError::INTERFACE_NOT_INITIALIZED is returned if the interface has not been correctly initialized .
         */        
        virtual ManipulatorError getPosition(unsigned int jointIndex, float & position);

        /**
         * \brief Copies the most current joint position values into positions. Units are in \f$radians\f$ for revolute joints and
         *         \f$meters\f$ for prismatic joints.
         * \param[out] positions Reference to vector where the current joint position values will be copied.
         * \return ManipulatorError::NO_ERROR is returned when the current joint position values are successfully copied to positions.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of positions does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *          that the values in positions have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *          cannot report an accurate reading of its position.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing position data is unavailable.\n
         */              
        virtual ManipulatorError getPosition(std::vector<float> & positions);

        /**
         * \brief Copies the most current joint velocity value for the joint referenced by jointIndex into velocity. Units are in
         *         \f$radians/second\f$ for revolute joints and \f$meters/second\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] velocity Reference to memory where the current joint velocity value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint velocity is successfully copied to velocity.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in velocity has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its velocity.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing velocity data is unavailable.\n
         */              
        virtual ManipulatorError getVelocity(unsigned int jointIndex, float & velocity);

        /**
         * \brief Copies the most current joint velocity values into velocities. Units are in \f$radians/second\f$ for revolute joints and
         *         \f$meters/second\f$ for prismatic joints.
         * \param[out] velocities Reference to vector where the current joint velocity values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint velocity values are successfully copied to velocities.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of velocities does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in velocities have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its velocity.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing velocity data is unavailable.\n
         */         
        virtual ManipulatorError getVelocity(std::vector<float> & velocities);

        /**
         * \brief Copies the most current joint acceleration value for the joint referenced by jointIndex into accel. Units are in 
         *         \f$radians/second^2\f$ for revolute joints and \f$meters/second^2\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] accel Reference to memory where the current joint acceleration value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint acceleration is successfully copied to accel.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in accel has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its acceleration.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing acceleration data is unavailable.\n
         */    
        virtual ManipulatorError getAcceleration(unsigned int jointIndex, float & accel);

        /**
         * \brief Copies the most current joint acceleration values into accelerations. Units are in \f$radians/second^2\f$ for revolute joints
         *         and \f$meters/second^2\f$ for prismatic joints.
         * \param[out] accelerations Reference to vector where the current joint acceleration values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint acceleration values are successfully copied to accelerations.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of accelerations does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in accelerations have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its acceleration.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing acceleration data is unavailable.\n
         */       
        virtual ManipulatorError getAcceleration(std::vector<float> & accelerations);
        
        /**
         * \brief Copies the most current joint torque/force value for the joint referenced by jointIndex into torque. Units are in 
         *         \f$newton*meters\f$ for revolute joints and \f$newtons\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] torque Reference to memory where the current joint torque/force value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint torque/force is successfully copied to torque.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in torque has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its torque/force.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing torque/force data is unavailable.\n
         */    
        virtual ManipulatorError getTorque(unsigned int jointIndex, float & torque);
        
        /**
         * \brief Copies the most current joint torque/force values into torques_forces. Units are in \f$newton*meters\f$ for revolute joints
         *         and \f$newtons\f$ for prismatic joints.
         * \param[out] torques_forces Reference to vector where the current joint torque/force values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint acceleration values are successfully copied to torques_forces.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of torques_forces does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in torques_forces have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its torque/force.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing torque/force data is unavailable.\n
         */
        virtual ManipulatorError getTorque(std::vector<float> & torques_forces);
        
        /**
         * \brief Copies the most recent motor current value for the joint referenced by jointIndex into current. Units are in 
         *         \f$amperes\f$.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] current Reference to memory where the most recent motor current value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the most recent motor current value is successfully copied to current.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in current has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its motor current.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing motor current data is unavailable.\n
         */   
        virtual ManipulatorError getMotorCurrent(unsigned int jointIndex, float & current);
        
        /**
         * \brief Copies the most recent motor current values into motorCurrents. Units are in \f$amperes\f$.
         * \param[out] motorCurrents Reference to vector where the most recent motor current values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the most recent motor current values are successfully copied to motorCurrents.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of motorCurrents does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in motorCurrents have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its motor current.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing motor current data is unavailable.\n
         */
        virtual ManipulatorError getMotorCurrent(std::vector<float> & motorCurrents);
        
        /**
         * \brief Copies the most recent volumetric flow value for the joint referenced by jointIndex into flow. Units are in 
         *         \f$meter^3/second\f$.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] flow Reference to memory where the most recent volumetric flow value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the most recent volumetric flow value is successfully copied to flow.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in flow has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its volumetric flow.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing volumetric flow data is unavailable.\n
         */ 
        virtual ManipulatorError getVolumetricFlow(unsigned int jointIndex, float & flow);
        
        /**
         * \brief Copies the most recent volumetric flow values into flows. Units are in \f$meter^3/second\f$.
         * \param[out] flows Reference to vector where the most recent volumetric flow values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the most recent volumetric flow values are successfully copied to flows.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of flows does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in flows have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its volumetric flow.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing volumetric flow data is unavailable.\n
         */
        virtual ManipulatorError getVolumetricFlow(std::vector<float> & flows);
        
        /**
         * \brief Copies the most recent temperature value for the joint referenced by jointIndex into flow. Units are in 
         *         \f$Celsius\f$.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] temp Reference to memory where the most recent temperature value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the most recent temperature value is successfully copied to temp.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in temp has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its temperature.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing temperature data is unavailable.\n
         */ 
        virtual ManipulatorError getTemperature(unsigned int jointIndex, float & temp);
        
        /**
         * \brief Copies the most recent temperature values into actuatorTemperatures. Units are in \f$Celsius\f$.
         * \param[out] actuatorTemperatures Reference to vector where the most recent temperature values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the most recent temperature values are successfully copied to
         *            actuatorTemperatures.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of actuatorTemperatures does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in actuatorTemperatures have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its temperature.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing temperature data is unavailable.\n
         */
        virtual ManipulatorError getTemperature(std::vector<float> & actuatorTemperatures);
        
        /**
         * \brief Copies the most recent power value for the joint referenced by jointIndex into flow. Units are in 
         *         \f$watts\f$.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] power Reference to memory where the most recent power value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the most recent power value is successfully copied to power.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in power has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its power.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing power data is unavailable.\n
         */ 
        virtual ManipulatorError getPower(unsigned int jointIndex, float & power);
        
        /**
         * \brief Copies the most recent power values into actuatorTemperatures. Units are in \f$watts\f$.
         * \param[out] powers Reference to vector where the most recent power values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the most recent power values are successfully copied to powers.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of powers does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in powers have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its power.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing power data is unavailable.\n
         */
        virtual ManipulatorError getPower(std::vector<float> & powers);
        
        
        /**
         * \brief Copies the most current joint position error value for the joint referenced by jointIndex into positionError. Units are in
         *         \f$radians\f$ for revolute joints and \f$meters\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] positionError Reference to memory where the current joint position error value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint position error is successfully copied to positionError.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in positionError has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its position error.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing position data is unavailable.\n
         */
        virtual ManipulatorError getPositionError(unsigned int jointIndex, float & positionError);
        
        /**
         * \brief Copies the most current joint position error values into positionError. Units are in \f$radians\f$ for revolute joints and
         *         \f$meters\f$ for prismatic joints.
         * \param[out] positionError Reference to vector where the current joint position error values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint position error values are successfully copied to positionError.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of positionError does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in positionError have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its position error.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing position data is unavailable.\n
         */  
        virtual ManipulatorError getPositionError(std::vector<float> & positionError);
        
        /**
         * \brief Copies the most current joint velocity error value for the joint referenced by jointIndex into velocityError. Units are in
         *         \f$radians/second\f$ for revolute joints and \f$meters/second\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] velocityError Reference to memory where the current joint velocity error value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint velocity error is successfully copied to velocityError.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in velocityError has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its velocity error.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing velocity data is unavailable.\n
         */
        virtual ManipulatorError getVelocityError(unsigned int jointIndex, float & velocityError);
        
        /**
         * \brief Copies the most current joint velocity error values into velocityError. Units are in \f$radians/second\f$ for revolute joints and
         *         \f$meters/second\f$ for prismatic joints.
         * \param[out] velocityError Reference to vector where the current joint velocity error values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint velocity error values are successfully copied to velocityError.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of velocityError does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in velocityError have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its velocity error.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing velocity data is unavailable.\n
         */  
        virtual ManipulatorError getVelocityError(std::vector<float> & velocityError);
        
        /**
         * \brief Copies the most current joint acceleration error value for the joint referenced by jointIndex into accelError. Units are in
         *         \f$radians/second\f$ for revolute joints and \f$meters/second\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] accelError Reference to memory where the current joint acceleration error value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint acceleration error is successfully copied to accelError.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in accelError has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its acceleration error.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing acceleration data is unavailable.\n
         */
        virtual ManipulatorError getAccelerationError(unsigned int jointIndex, float & accelError);
        
        /**
         * \brief Copies the most current joint acceleration error values into accelError. Units are in \f$radians/second^2\f$ 
         *         for revolute joints and \f$meters/second^2\f$ for prismatic joints.
         * \param[out] accelError Reference to vector where the current joint acceleration error values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint acceleration error values are successfully copied to accelError.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of accelError does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in accelError have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its acceleration error.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing acceleration data is unavailable.\n
         */ 
        virtual ManipulatorError getAccelerationError(std::vector<float> & accelError);
        
        /**
         * \brief Copies the most current joint torque error value for the joint referenced by jointIndex into torqueError. Units are in
         *         \f$newton*meters\f$ for revolute joints and \f$newtons\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] torqueError Reference to memory where the current joint torque error value will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint torque error is successfully copied to torqueError.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the value in torqueError has not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot report an accurate reading of its torque error.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing torque data is unavailable.\n
         */
        virtual ManipulatorError getTorqueError(unsigned int jointIndex, float & torqueError);
        
        /**
         * \brief Copies the most current joint torque error values into torqueError. Units are in \f$newton*meters\f$ for revolute joints and
         *         \f$newtons\f$ for prismatic joints.
         * \param[out] torqueError Reference to vector where the current joint torque error values will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the current joint torque error values are successfully copied to torqueError.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of torqueError does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the values in torqueError have not been changed or may not be accurate.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any of the joints are not calibrated and thus
         *           cannot report an accurate reading of its torque error.\n
         *         ManipulatorError::NO_FEEDBACK is returned if a sensor providing torque data is unavailable.\n
         */  
        virtual ManipulatorError getTorqueError(std::vector<float> & torqueError);
        
        
        /**
         * \brief Returns boolean indicating whether or not the interface is actively communicating with the manipulator. 
         * \return true if the interface is able to communicate with the manipulator\n
         *         false if the interface is not getting a response from the manipulator
         */
        virtual bool haveCommunication();

        /**
         * \brief Returns boolean indicating whether or not the manipulator joints are calibrated and know their absolute position. 
         * \return true if all of the joints are calibrated\n
         *         false if any of the joints are not calibrated
         */
        virtual bool isCalibrated();
        
        /**
         * \brief Sets boolean value of isCalibrated to indicate whether or not the joint referenced by jointIndex is calibrated and
         *         can report its absolute position.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[out] isCalibrated Boolean value representing calibration state of joint referenced by jointIndex.
         * \return ManipulatorError::NO_ERROR is returned when the calibration state of the joint referenced by jointIndex is
         *          successfully copied to isCalibrated.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *          that the current calibration status is really unknown.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the encoder is unavailable.\n
         */
        virtual ManipulatorError getEncoderCalibrationStatus(unsigned int jointIndex, bool & isCalibrated);
        
        /**
         * \brief Sets boolean values of encoderCalibrated to indicate whether or not the corresponding joint is calibrated and
         *         can report its absolute position.
         * \param[out] encoderCalibrated Reference to vector where the calibration status for each joint/encoder will be copied.
         * \return ManipulatorError::NO_ERROR is returned when the calibration state of each joint is successfully copied to encoderCalibrated.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of encoderCalibrated does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *          that the current calibration status is really unknown.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the encoder is unavailable.\n
         */
        virtual ManipulatorError getEncoderCalibrationStatus(std::vector<bool> & encoderCalibrated);
        
        /**
         * \brief Sets boolean value of isAlive to indicate whether or not the position feedback sensor for the joint referenced 
         *         by jointIndex is responding.
         * \param[in] jointIndex Index value for desired joint position feedback sensor. The range of jointIndex is [0, N-1].
         * \param[out] isAlive Boolean value representing health status of joint position feedback sensor referenced by jointIndex.
         * \return   ManipulatorError::NO_ERROR is returned when the position feedback sensor health status of the joint referenced 
         *            by jointIndex is successfully copied to isAlive.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the current position feedback sensor health status is really unknown.\n
         */
        virtual ManipulatorError getEncoderHealthStatus(unsigned int jointIndex, bool & isAlive);
        
        /**
         * \brief Sets boolean values of feedbackHealth to indicate whether or not the position feedback sensor for each joint is responding.
         * \param[out] feedbackHealth Reference to vector where health status of each joint position feedback sensor will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the position feedback sensor health status of each joint is successfully 
         *            copied to feedbackHealth.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of feedbackHealth does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the current position feedback sensor health status is really unknown.\n
         */
        virtual ManipulatorError getEncoderHealthStatus(std::vector<bool> & feedbackHealth);
        
        /**
         * \brief Sets boolean value of isAlive to indicate whether or not the torque/force feedback sensor for the joint referenced 
         *         by jointIndex is responding.
         * \param[in] jointIndex Index value for desired joint torque/force feedback sensor. The range of jointIndex is [0, N-1].
         * \param[out] isAlive Boolean value representing health status of joint torque/force feedback sensor referenced by jointIndex.
         * \return   ManipulatorError::NO_ERROR is returned when the torque/force feedback sensor health status of the joint referenced 
         *            by jointIndex is successfully copied to isAlive.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the current torque/force feedback sensor health status is really unknown.\n
         */
        virtual ManipulatorError getTorqueFeedbackHealthStatus(unsigned int jointIndex, bool & isAlive);
        
        /**
         * \brief Sets boolean values of feedbackHealth to indicate whether or not the torque/force feedback sensor for each joint is responding.
         * \param[out] feedbackHealth Reference to vector where health status of each joint torque/force feedback sensor will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the torque/force feedback sensor health status of each joint is successfully 
         *            copied to feedbackHealth.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of feedbackHealth does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the current torque/force feedback sensor health status is really unknown.\n
         */
        virtual ManipulatorError getTorqueFeedbackHealthStatus(std::vector<bool> & feedbackHealth);
        
        /**
         * \brief Sets boolean value of isAlive to indicate whether or not the motor current feedback sensor for the joint referenced 
         *         by jointIndex is responding.
         * \param[in] jointIndex Index value for desired joint motor current feedback sensor. The range of jointIndex is [0, N-1].
         * \param[out] isAlive Boolean value representing health status of joint motor current feedback sensor referenced by jointIndex.
         * \return   ManipulatorError::NO_ERROR is returned when the motor current feedback sensor health status of the joint referenced 
         *            by jointIndex is successfully copied to isAlive.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the current motor current feedback sensor health status is really unknown.\n
         */
        virtual ManipulatorError getCurrentFeedbackHealthStatus(unsigned int jointIndex, bool & isAlive);
        
        /**
         * \brief Sets boolean values of feedbackHealth to indicate whether or not the motor current feedback sensor for each joint is responding.
         * \param[out] feedbackHealth Reference to vector where health status of each joint motor current feedback sensor will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the motor current feedback sensor health status of each joint is successfully 
         *            copied to feedbackHealth.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of feedbackHealth does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the current motor current feedback sensor health status is really unknown.\n
         */
        virtual ManipulatorError getCurrentFeedbackHealthStatus(std::vector<bool> & feedbackHealth);
        
        /**
         * \brief Sets boolean value of isAlive to indicate whether or not the volumetric flow feedback sensor for the joint referenced 
         *         by jointIndex is responding.
         * \param[in] jointIndex Index value for desired joint volumetric flow feedback sensor. The range of jointIndex is [0, N-1].
         * \param[out] isAlive Boolean value representing health status of joint volumetric flow feedback sensor referenced by jointIndex.
         * \return   ManipulatorError::NO_ERROR is returned when the volumetric flow feedback sensor health status of the joint referenced 
         *            by jointIndex is successfully copied to isAlive.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the current volumetric flow feedback sensor health status is really unknown.\n
         */
        virtual ManipulatorError getVolumetricFlowFeebackHealthStatus(unsigned int jointIndex, bool & isAlive);
        
        /**
         * \brief Sets boolean values of feedbackHealth to indicate whether or not the volumetric flow feedback sensor for each joint is responding.
         * \param[out] feedbackHealth Reference to vector where health status of each joint volumetric flow feedback sensor will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the volumetric flow feedback sensor health status of each joint is successfully 
         *            copied to feedbackHealth.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of feedbackHealth does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the current volumetric flow feedback sensor health status is really unknown.\n
         */
        virtual ManipulatorError getVolumetricFlowFeebackHealthStatus(std::vector<bool> & feedbackHealth);
        
        /**
         * \brief Sets boolean value of isAlive to indicate whether or not the temperature feedback sensor for the joint referenced 
         *         by jointIndex is responding.
         * \param[in] jointIndex Index value for desired joint temperature feedback sensor. The range of jointIndex is [0, N-1].
         * \param[out] isAlive Boolean value representing health status of joint temperature feedback sensor referenced by jointIndex.
         * \return   ManipulatorError::NO_ERROR is returned when the temperature feedback sensor health status of the joint referenced 
         *            by jointIndex is successfully copied to isAlive.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the current temperature feedback sensor health status is really unknown.\n
         */
        virtual ManipulatorError getTemperatureFeedbackHealthStatus(unsigned int jointIndex, bool & isAlive);
        
        /**
         * \brief Sets boolean values of feedbackHealth to indicate whether or not the temperature feedback sensor for each joint is responding.
         * \param[out] feedbackHealth Reference to vector where health status of each joint temperature feedback sensor will be copied.
         * \return   ManipulatorError::NO_ERROR is returned when the temperature feedback sensor health status of each joint is successfully 
         *            copied to feedbackHealth.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of feedbackHealth does not match the number of joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that the current temperature feedback sensor health status is really unknown.\n
         */
        virtual ManipulatorError getTemperatureFeedbackHealthStatus(std::vector<bool> & feedbackHealth);
        
        
        /**
         * \brief Sets the target joint position value for the joint referenced by jointIndex. Units are in
         *         \f$radians\f$ for revolute joints and \f$meters\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[in] target Desired joint position value for the joint referenced by jointIndex.
         * \return   ManipulatorError::NO_ERROR is returned when the target joint position is accepted.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that commands cannot be executed.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot execute a set position command.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing position data is unavailable, indicating that
         *           a set position command cannot be executed.\n
         *         ManipulatorError::POSITION_LIMIT_VIOLATION is returned if target is outside the known limits of the joint referenced
         *           by jointIndex.\n
         */
        virtual ManipulatorError setTargetPosition(unsigned int jointIndex, float target);
        
        /**
         * \brief Sets the target joint position values for each joint. Units are in \f$radians\f$ for revolute joints 
         *         and \f$meters\f$ for prismatic joints.
         * \param[in] targets Desired joint position values for each joint.
         * \return   ManipulatorError::NO_ERROR is returned when every target joint position is accepted.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of targets does not match the number joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that commands cannot be executed.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any joint is not calibrated and thus
         *           cannot execute a set position command.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing position data is unavailable, indicating that
         *           a set position command cannot be executed.\n
         *         ManipulatorError::POSITION_LIMIT_VIOLATION is returned if any value in targets is outside the known limits of
         *           the corresponding joint.\n
         */
        virtual ManipulatorError setTargetPosition(const std::vector<float> & targets);
        
        /**
         * \brief Sets the target joint velocity value for the joint referenced by jointIndex. Units are in
         *         \f$radians\f$ for revolute joints and \f$meters\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[in] target Desired joint velocity value for the joint referenced by jointIndex.
         * \return   ManipulatorError::NO_ERROR is returned when the target joint velocity is accepted.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that commands cannot be executed.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot execute a set velocity command.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing velocity data is unavailable, indicating that
         *           a set velocity command cannot be executed.\n
         *         ManipulatorError::POSITION_LIMIT_REACHED is returned if the target commands the joint referenced by jointIndex to
         *           move past a position limit.\n
         *         ManipulatorError::VELOCITY_LIMIT_VIOLATION is returned if target is outside the known limits of the joint referenced
         *           by jointIndex.\n
         */
        virtual ManipulatorError setTargetVelocity(unsigned int jointIndex, float target);
        
        /**
         * \brief Sets the target joint velocity values for each joint. Units are in \f$radians\f$ for revolute joints 
         *         and \f$meters\f$ for prismatic joints.
         * \param[in] targets Desired joint velocity values for each joint.
         * \return   ManipulatorError::NO_ERROR is returned when every target joint velocity is accepted.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of targets does not match the number joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that commands cannot be executed.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any joint is not calibrated and thus
         *           cannot execute a set velocity command.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing velocity data is unavailable, indicating that
         *           a set velocity command cannot be executed.\n
         *         ManipulatorError::POSITION_LIMIT_REACHED is returned if any value in targets commands the corresponding joint to
         *           move past a position limit.\n
         *         ManipulatorError::VELOCITY_LIMIT_VIOLATION is returned if any value in targets is outside the known limits of the
         *           corresponding joint.\n
         */
        virtual ManipulatorError setTargetVelocity(const std::vector<float> & targets);
        
        /**
         * \brief Sets the target joint acceleration value for the joint referenced by jointIndex. Units are in
         *         \f$radians\f$ for revolute joints and \f$meters\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[in] target Desired joint acceleration value for the joint referenced by jointIndex.
         * \return   ManipulatorError::NO_ERROR is returned when the target joint acceleration is accepted.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that commands cannot be executed.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot execute a set acceleration command.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing acceleration data is unavailable, indicating that
         *           a set acceleration command cannot be executed.\n
         *         ManipulatorError::POSITION_LIMIT_REACHED is returned if the target commands the joint referenced by jointIndex to
         *           move past a position limit.\n
         *         ManipulatorError::VELOCITY_LIMIT_REACHED is returned if the target commands the joint referenced by jointIndex to
         *           exceed a velocity limit.\n
         *         ManipulatorError::ACCELERATION_LIMIT_VIOLATION is returned if target is outside the known limits of the joint referenced
         *           by jointIndex.\n
         */
        virtual ManipulatorError setTargetAcceleration(unsigned int jointIndex, float target);
        
        /**
         * \brief Sets the target joint acceleration values for each joint. Units are in \f$radians\f$ for revolute joints 
         *         and \f$meters\f$ for prismatic joints.
         * \param[in] targets Desired joint acceleration values for each joint.
         * \return   ManipulatorError::NO_ERROR is returned when every target joint acceleration is accepted.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of targets does not match the number joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that commands cannot be executed.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any joint is not calibrated and thus
         *           cannot execute a set acceleration command.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing acceleration data is unavailable, indicating that
         *           a set acceleration command cannot be executed.\n
         *         ManipulatorError::POSITION_LIMIT_REACHED is returned if any value in targets commands the corresponding joint to
         *           move past a position limit.\n
         *         ManipulatorError::VELOCITY_LIMIT_REACHED is returned if any value in targets commands the corresponding joint to
         *           exceed a velocity limit.\n
         *         ManipulatorError::ACCELERATION_LIMIT_VIOLATION is returned if any value in targets is outside the known limits of the
         *           corresponding joint.\n
         */
        virtual ManipulatorError setTargetAcceleration(const std::vector<float> & targets);
        
        /**
         * \brief Sets the target joint torque/force value for the joint referenced by jointIndex. Units are in
         *         \f$radians\f$ for revolute joints and \f$meters\f$ for prismatic joints.
         * \param[in] jointIndex Index value for desired joint. The range of jointIndex is [0, N-1].
         * \param[in] target Desired joint torque/force value for the joint referenced by jointIndex.
         * \return   ManipulatorError::NO_ERROR is returned when the target joint torque/force is accepted.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned when jointIndex is outside the valid range.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *           that commands cannot be executed.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if the joint referenced by jointIndex is not calibrated and thus
         *           cannot execute a set torque/force command.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing torque/force data is unavailable, indicating that
         *           a set torque/force command cannot be executed.\n
         *         ManipulatorError::POSITION_LIMIT_REACHED is returned if the target commands the joint referenced by jointIndex to
         *           move past a position limit.\n
         *         ManipulatorError::VELOCITY_LIMIT_REACHED is returned if the target commands the joint referenced by jointIndex to
         *           exceed a velocity limit.\n
         *         ManipulatorError::ACCELERATION_LIMIT_REACHED is returned if target commands the joint referenced by jointIndex to
         *           exceed an acceleration limit.\n
         *         ManipulatorError::TORQUE_LIMIT_VIOLATION is returned if target is outside the known limits of the joint referenced
         *           by jointIndex.\n
         */
        virtual ManipulatorError setTargetTorque(unsigned int jointIndex, float target);
        
        /**
         * \brief Sets the target joint torque/force values for each joint. Units are in \f$radians\f$ for revolute joints 
         *         and \f$meters\f$ for prismatic joints.
         * \param[in] targets Desired joint torque/force values for each joint.
         * \return ManipulatorError::NO_ERROR is returned when every target joint torque/force is accepted.\n
         *         ManipulatorError::NO_IMPLEMENTATION is returned if subclass does not override the base class implementation.\n
         *         ManipulatorError::INVALID_INDEX is returned if the size of targets does not match the number joints.\n
         *         ManipulatorError::NO_COMMUNICATION is returned if communication with the manipulator has been lost, indicating
         *          that commands cannot be executed.\n
         *         ManipulatorError::JOINT_NOT_CALIBRATED is returned if any joint is not calibrated and thus
         *          cannot execute a set torque/force command.\n
         *         ManipulatorError::NO_FEEDBACK is returned if the sensor providing torque/force data is unavailable, indicating that
         *          a set torque/force command cannot be executed.\n
         *         ManipulatorError::POSITION_LIMIT_REACHED is returned if any value in targets commands the corresponding joint to
         *          move past a position limit.\n
         *         ManipulatorError::VELOCITY_LIMIT_REACHED is returned if any value in targets commands the corresponding joint to
         *          exceed a velocity limit.\n
         *         ManipulatorError::ACCELERATION_LIMIT_REACHED is returned if any value in targets commands the corresponding joint to
         *          exceed an acceleration limit.\n
         *         ManipulatorError::TORQUE_LIMIT_VIOLATION is returned if any value in targets is outside the known limits of the
         *          corresponding joint.\n
         */
        virtual ManipulatorError setTargetTorque(const std::vector<float> & targets);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setTargetPositionVelocity(unsigned int jointIndex, float targetPosition, float targetVelocity);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setTargetPositionVelocity(const std::vector<float> & targetPositions, const std::vector<float> & targetVelocities);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setTargetPositionTime(unsigned int jointIndex, float targetPosition, float targetTime);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setTargetPositionTime(const std::vector<float> & targetPositions, const std::vector<float> & targetTimes);
        
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetPosition(unsigned int jointIndex, float & target);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetPosition(std::vector<float> & targets);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetVelocity(unsigned int jointIndex, float & target);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetVelocity(std::vector<float> & targets);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetAcceleration(unsigned int jointIndex, float & target);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetAcceleration(std::vector<float> & targets);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetTorque(unsigned int jointIndex, float & target);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetTorque(std::vector<float> & targets);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetPositionVelocity(unsigned int jointIndex, float & targetPosition, float & targetVelocity);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetPositionVelocity(std::vector<float> & targetPositions, std::vector<float> & targetVelocities);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetPositionTime(unsigned int jointIndex, float & targetPosition, float & targetTime);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError getTargetPositionTime(std::vector<float> & targetPositions, std::vector<float> & targetTimes);
        

        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError calibrate();
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError calibrate(unsigned int jointIndex);
        
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setMinimumPositionLimit(unsigned int jointIndex, float minimum);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setMinimumPositionLimit(const std::vector<float> & minimums);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setMaximumPositionLimit(unsigned int jointIndex, float maximum);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setMaximumPositionLimit(const std::vector<float> & maximums);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setPositionLimits(unsigned int jointIndex, float minimum, float maximum);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setPositionLimits(const std::vector<float> & minimums, const std::vector<float> & maximums);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setMaximumVelocityLimit(unsigned int jointIndex, float maximum);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setMaximumVelocityLimit(const std::vector<float> & maximums);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setMaximumAccelerationLimit(unsigned int jointIndex, float maximum);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setMaximumAccelerationLimit(const std::vector<float> & maximums);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setMaximumTorqueLimit(unsigned int jointIndex, float maximum);
        
        /**
         * \brief .
         * \param[in] 
         * \return 
         */
        virtual ManipulatorError setMaximumTorqueLimit(const std::vector<float> & maximums);
        
        /**
         * \brief Prints a listing of capabilities provided by this interface to stdout.
         * \return void
         */
        void printCapabilities();
        
        /**
         * \brief Appends a listing of capabilities provided by this interface to capabilitiesString.
         * \param[in] capabilitiesString
         * \return void
         */
        void printCapabilities(std::string & capabilitiesString);
    
    
};

#endif  // __MANIPULATOR_INTERFACE_INCLUDED__
