/*
 * InterfaceType.h
 *
 *  Created on: Mar 1, 2011
 *      Author: jteems
 */

#ifndef INTERFACE_TYPE_
#define INTERFACE_TYPE_

#include <string>
#include <ostream>

/**
 *****************************************************************************
 * \brief InterfaceType, a generic, templated type designed to be used as a
 * 		  base class for class-specific interfaces, to enable better use of
 * 		  Scott Myere's Item #18 (Effective C++, 3rd Ed.) ISBN: 0-321-33487-6
 *
 * 		  This paradigm essentially states the desire to make class interfaces
 * 		  easy to use correctly and hard to use incorrectly, and specifies using
 *  	  a typesafe enumeration, enabling the class designer to specifically
 *  	  allow the "correct" interface to be used.
 *
 *  	  We use this paradigm presently (3/1/11) in //API/DEV/DR_KIT/MiniEODManipulator
 *  	  and found it to be beneficial from a "how to use this library" standpoint
 *  	  but have found it to be tedious having to implement copy constructors,
 *        assignment operators, and the like for the various interfaces. This class
 *        is designed to be a base class for these types of interfaces and
 *        prevent having to rewrite that code for each interface.
 *
 *        The only present example using this base class is in //API/DEV/DEVEL_LIBS/InterfaceTypeSubclass
 *        which is used to validate the base class via the unit tests. An example of practically
 *        using this library as an interface has not yet been accomplished, but the
 *        examples in //API/DEV/DR_KIT/MiniEODManipulator demonstrate that. It would
 *        be best to use this template as a base class moving forward on new work, and
 *        if the need to refactor any interface classes exists, to then leverage this library
 *
 ****************************************************************************/
template <typename T> class InterfaceType;

template <typename T> std::ostream& operator<<(std::ostream&, const InterfaceType<T>&);

template <typename T>
class InterfaceType
{
private:
	T stateVal;
	std::string stateStr;
public:
	explicit InterfaceType(T state, std::string str);
	virtual ~InterfaceType();
	operator T();


	InterfaceType(const InterfaceType<T>& rhs);
	InterfaceType<T>& operator=(const InterfaceType<T>& rhs);

	bool operator==(const InterfaceType<T>& rhs) const;
	bool operator!=(const InterfaceType<T>& rhs) const;
	
	bool operator<(const InterfaceType<T>& rhs) const;

	
	friend std::ostream& operator<< <> (std::ostream&, const InterfaceType<T>&);
	
	std::string toString() const;
	
};



/**
 *****************************************************************************
 * \brief Constructor
 ****************************************************************************/
template<typename T> InterfaceType<T>::InterfaceType(T state, std::string str):
	stateVal(state),
	stateStr(str)
{

}

/**
 *****************************************************************************
 * \brief Destructor
 ****************************************************************************/
template<typename T> InterfaceType<T>::~InterfaceType()
{

}

/**
 *****************************************************************************
 * \brief Cast operator
 ****************************************************************************/
template<typename T> InterfaceType<T>::operator T()
{
	return stateVal;
}

/**
 *****************************************************************************
 * \brief Copy Constructor
 ****************************************************************************/
template<typename T> InterfaceType<T>::InterfaceType(const InterfaceType<T>& rhs):
		stateVal(rhs.stateVal),
		stateStr(rhs.stateStr)
{

}

/**
 *****************************************************************************
 * \brief Assignment Operator
 ****************************************************************************/
template<typename T> InterfaceType<T>& InterfaceType<T>::operator=(const InterfaceType<T>& rhs)
{
	stateVal = rhs.stateVal;
	stateStr = rhs.stateStr;
	return *this;
}

/**
 *****************************************************************************
 * \brief Equality Operator
 ****************************************************************************/
template<typename T> bool InterfaceType<T>::operator==(const InterfaceType<T>& rhs) const
{
	return (stateVal == rhs.stateVal);
}

/**
 *****************************************************************************
 * \brief Inequality Operator
 ****************************************************************************/
template<typename T> bool InterfaceType<T>::operator!=(const InterfaceType<T>& rhs) const
{
	return !(*this == rhs);
}

/**
 *****************************************************************************
 * \brief Less than Operator
 ****************************************************************************/
template<typename T> bool InterfaceType<T>::operator<(const InterfaceType<T>& rhs) const
{
	return (stateVal < rhs.stateVal);
}

/**
 *****************************************************************************
 * \brief OStream Operator
 ****************************************************************************/
template<typename T> std::ostream& operator<<(std::ostream &theStream, const InterfaceType<T>& rhs)
{
	return theStream << rhs.stateStr;
}

/**
 *****************************************************************************
 * \brief returns the string associated with the class
 ****************************************************************************/
template<typename T> std::string InterfaceType<T>::toString() const
{
	return stateStr;
}

#endif /* INTERFACE_TYPE_ */



