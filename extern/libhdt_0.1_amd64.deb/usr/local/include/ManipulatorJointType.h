// BEGIN_QNA_COPYRIGHT
// END_QNA_COPYRIGHT
// BEGIN_QNA_FILE_INFO

// ManipulatorJointType.h: <file description>
// Created Jul 26, 2011 by mcsencsits
// Updated Jul 27, 2011 by mcsencsits

// END_QNA_FILE_INFO

#ifndef MANIPULATORJOINTTYPE_H_
#define MANIPULATORJOINTTYPE_H_

#include <InterfaceType.h>

class ManipulatorJointType : public InterfaceType<unsigned char>
{
public:
   static ManipulatorJointType Revolute();
   static ManipulatorJointType Prismatic();

private:
   explicit ManipulatorJointType(unsigned char joint_val, std::string str);
};

#endif /* MANIPULATORJOINTTYPE_H_ */
