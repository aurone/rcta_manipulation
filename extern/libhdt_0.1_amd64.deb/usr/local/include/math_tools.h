#ifndef MATH_TOOLS_H
#define MATH_TOOLS_H
/**
 *
 * \file math_tools.h
 *
 * Based on:
 * Id: tools.h,v 1.16 2007/03/13 18:11:01 jaus Exp
 * Revision: 1.16
 * Date: 2007/03/13 18:11:01
 *
 * THIS WORK CONTAINS VALUABLE CONFIDENTIAL AND PROPRIETARY INFORMATION.
 * DISCLOSURE OR REPRODUCTION WITHOUT THE WRITTEN AUTHORIZATION OF Applied
 * Perception IS PROHIBITED. THIS UNPUBLISHED WORK BY Applied Perception
 * IS PROTECTED BY THE LAWS OF THE UNITED STATES AND OTHER
 * COUNTRIES. IF PUBLICATION OF THE WORK SHOULD OCCUR, THE FOLLOWING NOTICE
 * SHALL APPLY.
 *
 * "COPYRIGHT (C) 2003 Applied Perception ALL RIGHTS RESERVED."
 *
 * Applied Perception DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL Applied Perception BE LIABLE FOR ANY SPECIAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 *
 *
 **/

/*****************************************************************************/
/* math macro tools used */

#define SRANDOM srand
#define RANDOM rand
#define RAND_FLOAT(min, max)   ((RANDOM() % 10000) * (((max) - (min)) \
                                                      / 10000.0) + (min))
#define RAND_INT(min, max)     ((RANDOM() % ((max) - (min) + 1)) + (min))

/*
   #define ABS(arg)               (abs(arg))
   #define FABS(arg)               (fabs(arg))
*/

#define ABS(arg)               (((arg) < 0) ? (-1 * (arg)) : (arg))
#define FABS(arg)              (((arg) < 0.0) ? (-1.0 * (arg)) : (arg))

/*  This old version of round didn't work for negative 
    numbers (i.e. ROUND(-0.6) = 0.0) */
/* #define ROUND(arg)             ((float)(int)((arg) + 0.5)) */

/* FLOAT_SIGN returns 0.5 or -0.5 depending on sign of arg, it is used to fix
   ROUND to work for negative numbers as well as positive */
#define FLOAT_SIGN(arg)  (((int)(((arg) / (SQUARE(arg) + 2.0)) + 1.0)) - 0.5)

/* this version of round works for negative numbers, the reason FLOAT_SIGN has
   to be defined is that SIGN uses a conditional, which isn't allowed in 
   preprocessor */
#define ROUND(arg)     ((float)(int)((arg) + FLOAT_SIGN((float)arg)))
#define DOUBLE_ROUND(arg) ((double)(long int)((arg) + \
                                              FLOAT_SIGN((double) arg)))

/*#define DOUBLE_ROUND(arg) ((double)(unsigned int)((arg) + \
                                                  (0.5 * SGN((double)arg))))
*/

/* In this version of TRUNC, TRUNC(-2.4) = -2 and TRUNC(2.4) = 2 */
#ifndef TRUNC
#define TRUNC(arg)             ((float)(int)(arg))
#endif

/* FLOAT_SIGN2 returns -0.999999999 or 0 depending on sign of arg, it is
   used to fix TRUNC to work for negative numbers as well as positive */
#define FLOAT_SIGN2(arg)  (((int)(((arg) / (SQUARE(arg) + 2.0)) + 1.0)) - 0.999999999)

/* In this version of TRUNC, TRUNC(-2.4) = -3 and TRUNC(2.4) = 2 */
#define TRUNC2(arg)     ((float)(int)((arg) + FLOAT_SIGN2((float)arg)))

#define FLOOR(arg)             TRUNC2(arg)
#define CEILING(arg)           TRUNC2((arg) + 0.999999)

#define SGN(arg)               (((arg) > 0) ? 1 : -1)
#define SIGN(arg)              SGN(arg)
#ifndef MAX
#define MAX(arg1, arg2)        (((arg1) > (arg2)) ? (arg1) : (arg2))
#endif
#ifndef MIN
#define MIN(arg1, arg2)        (((arg1) < (arg2)) ? (arg1) : (arg2))
#endif
#define MAX3(arg1, arg2, arg3) MAX(MAX(arg1, arg2), arg3)
#define MIN3(arg1, arg2, arg3) MIN(MIN(arg1, arg2), arg3)
#define MAX4(arg1, arg2, arg3, arg4) MAX(MAX3(arg1, arg2, arg3), arg4)
#define MIN4(arg1, arg2, arg3, arg4) MIN(MIN3(arg1, arg2, arg3), arg4)
#define BOUND(arg1, arg2, arg3) MAX(MIN(MAX(arg2, arg3), arg1), \
                                    MIN(arg2, arg3))
#define LIMIT(arg1, arg2, arg3) BOUND(arg1, arg2, arg3)

/* to convert between degrees and radians */
#define DEG_TO_RAD(arg)    ((double)(arg) * (M_PI / 180.0))
#define RAD_TO_DEG(arg)    ((double)(arg) * (180.0 / M_PI))

/* common angles in radians */
#define IN_RAD_90          (M_PI / 2.0)
#define IN_RAD_45          (M_PI / 4.0)
#define IN_RAD_180          (M_PI)

/* regular math functions with correct casts */
#define SIN(deg_arg)       sin((double)(deg_arg))
#define COS(deg_arg)       cos((double)(deg_arg))
#define TAN(deg_arg)       tan((double)(deg_arg))
#define ASIN(arg)          asin((double)(arg))
#define ACOS(arg)          acos((double)(arg))
#define ATAN(arg)          atan((double)(arg))

#define DEBUG_SQRT(arg) (((arg) < 0.0) ? ((double)printf("file %s, line %d: argument to SQRT = %.3f\n", __FILE__, __LINE__, arg)) : sqrt((double)(arg)))
#define NORMAL_SQRT(arg)   sqrt((double)(arg))
#define SQRT(arg)          NORMAL_SQRT(arg)
/* #define SQRT(arg)          DEBUG_SQRT(arg) */
#define EXP(arg)           exp((double)(arg))
#define SQUARE(arg)        ((arg) * (arg))
#define CUBE(arg)          ((arg) * (arg) * (arg))
#define POW(arg1, arg2)    pow((double)(arg1), (double)(arg2))

#ifndef NORM2
#define NORM2(x, y)      (sqrt((x)*(x)+(y)*(y)))
#endif
#ifndef NORM3
#define NORM3(x, y, z)   (sqrt((x)*(x)+(y)*(y)+(z)*(z)))
#endif

#ifndef HYPOTENEUSE
#define HYPOTENEUSE(a,b) (sqrt(SQR(a)+SQR(b)))
#endif
#ifndef COS_LAW
#define COS_LAW(side1, side2, theta) \
        (sqrt(SQR(side1)+SQR(side2)-2.0*(side1)*(side2)*cos(theta)))
#endif
#ifndef INV_COS_LAW
#define INV_COS_LAW(oppSide, side1, side2) \
        (acos((SQR(side1)+SQR(side2)-SQR(oppSide))/(2.0*(side1)*(side2))))
#endif
#ifndef XOR
#define XOR(a,b)	( ((a) && !(b)) || (!(a) && (b)))
#endif

#ifndef NEAR
#define NEAR(x,y,epsilon) (((x) > (y)-(epsilon)) && ((x) < (y)+(epsilon))) 
#endif

/*
 * TRUE if x is greater than min_x and less than max_x, else FALSE
 */
#ifndef UNDER_LIMITS
#define UNDER_LIMITS(max_x, x, min_x) \
        ((x)>(max_x)?(max_x):((x)<(min_x)?(min_x):(x)))
#endif

/*
 * TRUE if x is greater than or equal to min_x and less than or equal to
 * max_x, else FALSE
 */
#ifndef WITHIN_LIMITS
#define WITHIN_LIMITS(max_x, x, min_x) \
        ((x)>=(max_x)?(max_x):((x)<=(min_x)?(min_x):(x)))
#endif

/*
 * Same as WITHIN_LIMITS, just organized differently.  Anyone using this?
 */
#ifndef IN_RANGE
#define IN_RANGE(val,lo,hi) ((val) >= (lo) && (val) <= (hi))
#endif

#define DISTANCE4(x1, y1, x2, y2) ( (double)SQRT((double)(SQUARE((x1)-(x2))) + \
						 (double)(SQUARE((y1)-(y2)))) )

#define DISTANCE(arg1, arg2) (SQRT((double)SQUARE(arg1) + \
                                   (double)SQUARE(arg2)))
#define DISTANCE_3D(arg1, arg2, arg3) (SQRT((double)SQUARE(arg1) + \
                                            (double)SQUARE(arg2) + \
                                            (double)SQUARE(arg3)))

#define ALMOST_DISTANCE(arg1, arg2) ((double)SQUARE(arg1) + \
                                     (double)SQUARE(arg2))

#define ALMOST_DISTANCE_3D(arg1, arg2, arg3) ((double)SQUARE(arg1) + \
                                              (double)SQUARE(arg2) + \
                                              (double)SQUARE(arg3))

#define BETWEEN(arg1, arg2, arg3) ((((arg1) < (MAX(arg2, arg3))) && \
                                    ((arg1) > (MIN(arg2, arg3)))) ? 1 : 0)

#define BETWEEN_OR_EQUAL(arg1, arg2, arg3) \
              ((((arg1) <= (MAX(arg2, arg3))) && \
                ((arg1) >= (MIN(arg2, arg3)))) ? 1 : 0)

/* returns "value" with the "bit" bit set to 1 */
#define SETBIT(value, bit)  (value | (1 << bit))   

/* returns value of "bit" in "value" */
#define GETBIT(value, bit)  ((value & (1 << bit)) ? 1 : 0)

#ifndef ANGLE_NORMALIZE
/* Brings an angle in the range (-M_PI, M_PI] */
#define ANGLE_NORMALIZE(x) while ((x) <= -M_PI) (x) += (2.0 * (M_PI)); \
                           while ((x) > M_PI) (x) -= (2.0 * (M_PI));   
#endif
#ifndef ANGLE_NORMALIZE_DEG
/* Brings an angle in the range (-M_PI, M_PI] */
#define ANGLE_NORMALIZE_DEG(x) while ((x) <= -180.0) (x) += (2.0 * (180.0)); \
                           while ((x) > 180.0) (x) -= (2.0 * (180.0));   
#endif
#ifndef ANGLE_NORMALIZE2
/* Brings an angle in the range [0, 2*M_PI) */
#define ANGLE_NORMALIZE2(x) while ((x) < 0) (x) += (2.0 * (M_PI)); \
                           while ((x) >= (2.0 * (M_PI))) (x) -= (2.0 * (M_PI));   
#endif

/* Conversion Multipliers. */
#define M2F        3.2808       /* Meters to Feet */
#define MILES2FT  5280.0        /* Miles to Feet */
#define F2M    (1.0/M2F)        /* Feet to Meters */
#define HRS2SEC  3600.0         /* Hours to Seconds */
#define METERS2MILES (M2F / MILES2FT)
#define MILES2METERS (1.0 / METERS2MILES)
#define MPH2MPS  (MILES2METERS/HRS2SEC) /* Miles/hour to meters/sec */
#define MPS2MPH  (1.0/MPH2MPS)  /* meters/sec to Miles/hour */
#define MPH2KPH  (MPH2MPS * 3600.0 / 1000.0)
#define PI    3.1415926535898   /* PI */
#define D2R    (M_PI/180.0)       /* Degrees to radians */
#define R2D    (180.0/M_PI)       /* Radians to Degrees */
#define UNKNOWN          -10000000.0
#define BIG_NUM           10000000.0
#define STRAIGHT_AHEAD   BIG_NUM

/* Some units conversion constants */
#define IN_TO_CM(in)	((in) * 2.5400)           /* Inches to centimeters */ 
#define IN_TO_M(in)	((in) * 0.0254)                /* Inches to meters */ 

#define CM_TO_IN(cm)    ((cm) / 2.5400)           /* Centimeters to inches */

#define M_TO_IN(m)	((m) * 39.370079)               /* Meters to inches */ 
#define M_TO_FT(m)	((m) * 3.28084)                   /* Meters to feet */ 

#define FT_TO_M(ft)     ((ft) / 3.28084)                  /* feet to meters */

#define FT_IN_MI        (5280.0000)             /* number of feet in a mile */
#define FT_TO_MI(ft)    ((ft) / FT_IN_MI)       /* feet  -> miles */

#define MI_TO_FT(mi)    ((mi) * FT_IN_MI)            /* miles -> feet  */
#define MI_TO_M(mi)     ( (FT_TO_M(MI_TO_FT(mi))) ) /* miles -> meters */

#define MPS_TO_MPH(mps) FT_TO_MI(M_TO_FT(mps*60.0*60.0)) /* m/s -> mph */

#define M_TO_MI(m)	(M_TO_FT(m)/FT_IN_MI)
#define M_TO_KM(m)	(m/(METERS)1000.0)

#define M_TO_CM(m)	  (((double)m)*M2CM)
#define CM_TO_M(cm)       (((double)cm)*CM2M)

#define USEC_TO_SEC(t)    (((double)t)*USEC2SEC)
#define SEC_TO_USEC(t)    (((double)t)*SEC2USEC)

#define MSEC_TO_SEC(t)    (((double)t)*MSEC2SEC)
#define SEC_TO_MSEC(t)    (((double)t)*SEC2MSEC)

#define NSEC_TO_SEC(t)    (((double)t)*NSEC2SEC)
#define SEC_TO_NSEC(t)    (((double)t)*SEC2NSEC)

#define M_TO_MM(m)	  (((double)m)*M2MM)
#define MM_TO_M(mm)       (((double)mm)*MM2M)

#define RAD_TO_MRAD(rad)  (((double)rad)*RAD2MRAD)
#define MRAD_TO_RAD(mrad) (((double)mrad)*MRAD2RAD)

#define DEG2RAD		      0.017453292519943295474
#define RAD2DEG		      57.295779513082322865

#define CM2M                  0.01
#define M2CM                  100.0

#define IN2CM                 2.54
#define CM2IN                 0.393700787402

#define NSEC2SEC              (1e-9)
#define SEC2NSEC              1e9

#define USEC2SEC              (1e-6)
#define SEC2USEC              1e6

#define MSEC2SEC              (1e-3)
#define SEC2MSEC              1e3

#define MM2M                  (1e-3)
#define M2MM                  1e3

#define RADM2RAD              (1e-3)
#define RAD2MRAD              1e3


/* Age codes. */
#define NEW                   1
#define OLD                   0


#define GENERAL_BUFFER_SIZE   256
#define GetTickCount()	(1000*clock())/CLOCKS_PER_SEC

#define 	ERROR_MESSAGE(x)				(fprintf(stderr, "%s\n", x))

#define MEASURE_TIME_OF_FUNCTION(func, count, strName)	\
			{				\
			    int _end=0;							\
				int _cnt;							\
				int _max = MAX (1, count);	\
			    int _start=GetTickCount();			\
				for (_cnt=0; _cnt<_max; _cnt++)			\
					func;							\
			    _end=GetTickCount();					\
			    if (count == _max) {			\
				char _msg[256];						\
				sprintf (msg, "%s took %.2f milliseconds/iteration (%d iterations)", 	\
					strName, (float) (_end - _start) / (float) _max, _max);	\
				ERROR_MESSAGE(_msg);					\
			    }				\
			}

/*Weight conversion */
#define LB_IN_KG 2.20462262
#define LB_TO_KG(lbs) (lbs/LB_IN_KG)
#define KG_TO_LB(kg) (kg*LB_IN_KG)

#endif
