// BEGIN_QNA_COPYRIGHT
// END_QNA_COPYRIGHT
// BEGIN_QNA_FILE_INFO

// RADMessages.h: A set of structs to aid in parsing and constructing RAD node messages
// Created Sep  5, 2012 by matthew.csencsits
// Updated Sep 18, 2012 by matthew.csencsits

// END_QNA_FILE_INFO

#ifndef RADMESSAGES_H_
#define RADMESSAGES_H_

#include <cstdint>
#include <cmath>

namespace RAD{

enum NodeID
{
   SHOULDER_FLEX_EXTEND = 1,
   SHOULDER_AB_AD,
   SHOULDER_HUMERAL_ROTATOR,
   ELBOW,
   WRIST_ROTATOR,
   WRIST_DEVIATOR,
   WRIST_FLEXION,
   CONTROLLER = 9
};

enum SWState
{
   SW_INIT=0,
   SW_PRG,
   SW_FS,
   SW_NOS,
   SW_NOS_IDLE,
   SW_NOS_SLEEP,
   SW_DEBUG,
   SW_RESET
};

enum BITContext{
   BIT_RESET = 0,
   BIT_OTHER = 1
};

enum BITStatus{
   BIT_NO_ERROR = 0,
   BIT_CRITICAL_ERROR,
   BIT_NON_CRITICAL_ERROR
};

enum FOCState{
   FOC_IDLE=0,
   FOC_INIT,
   FOC_START,
   FOC_RUN,
   FOC_STOP,
   FOC_BRAKE,
   FOC_EOT,
   FOC_FAULT
};

enum CmdError{
   INVALID_ID                = 0,   // id value does not match value stored in flash
   INVALID_PARAMETER_ID      = 0x02,// Parameter ID is not recognized
   INVALID_FRAME_SEQUENCE    = 0x03,// Frame received out of sequence
   INVALID_CHECKSUM          = 0x04,// Mismatch in sent and calculated checksum
   FLASH_WRITE_ERROR         = 0x05,// Some error while writing to flash
   INVALID_STATE_CHANGE      = 0x06,// Invalid state transition requested
   CRC_ERROR                 = 0x07,// ?
   INVALID_ADDRESS           = 0x0D,// Invalid address provided in memory peek command
   INVALID_MEMORY            = 0x0E,// Memory space is not valid (not RAM, Flash, or Register)
   STATE_ERROR               = 0x0F,// Command not allowed in current software state
   INVALID_MSG_ID            = 0x10,// Command ID received was unknown
   BAD_IMAGE_SIZE            = 0x11,// Image size provided was invalid (too large)
   INVALID_IMAGE_SIZE        = 0x12,// Number of bytes sent in image does not match payload specified
   INVALID_CAN_TYPE          = 0x13,// CAN frame sent was not a start, continuing, or end of single frame
   INVALID_FRAME_LENGTH      = 0x14,// Length specified in CAN header and payload size sent do not match
   INVALID_MESSAGE_LENGTH    = 0x15,// The number of message bytes does not match expected for that command
   INVALID_COMMAND_PARAMETER = 0x16 // A parameter in the command message had an invalid value
};

enum MessageID
{
   CMD_NODE_RESET          = 2,
   CMD_CHANGE_SW_STATE     = 3,
   MSG_BIT_ERROR_TELEMETRY = 4,
   CMD_CONTROL             = 10,
   CMD_IMPEDANCE           = 11,
   MSG_HS_TELEMETRY        = 12,
   MSG_LS_TELEMETRY        = 13,
   CMD_STATUS_REQUEST      = 28,
   MSG_STATUS_TELEMETRY    = 29,
   MSG_CMD_ACK             = 32,
   MSG_CMD_NACK            = 33
};

class NodeResetCmdPayload{
public:
   NodeResetCmdPayload();

   NodeResetCmdPayload& Id(NodeID joint);
   NodeID Id() const;

protected:
   uint8_t node_id;
} __attribute__((__packed__));


class ChangeModeCmdPayload{
public:
   ChangeModeCmdPayload();

   ChangeModeCmdPayload& Id(NodeID joint);
   NodeID Id() const;

   ChangeModeCmdPayload& State(SWState state);
   SWState State() const;

protected:
   uint8_t node_id;
   uint8_t sw_state;
} __attribute__((__packed__));


class ControlCmdPayload{
public:
   ControlCmdPayload();

   ControlCmdPayload& Position(float radians);
   float Position() const;

   ControlCmdPayload& Velocity(float rads_per_sec);
   float Velocity() const;

   ControlCmdPayload& Torque(float newton_meters);
   float Torque() const;

   ControlCmdPayload& MotorCurrentLimit(float amps);
   float MotorCurrentLimit() const;

private:
   static const float rad_per_bit;
   static const float rad_per_sec_per_bit;
   static const float nm_per_bit;
   static const float amps_per_bit;

   int16_t  position;
   int16_t  velocity;
   int16_t  torque;
   uint16_t current_limit;
} __attribute__((__packed__));


class ImpedanceCmdPayload{
public:
   ImpedanceCmdPayload();

   ImpedanceCmdPayload& Inertia(float kg_m2);
   float Inertia() const;

   ImpedanceCmdPayload& Damping(float newton_sec_per_m);
   float Damping() const;

   ImpedanceCmdPayload& Stiffness(float newton_meter_per_rad);
   float Stiffness() const;

protected:
   static const float kgm2_per_bit;
   static const float ns_per_m_per_bit;
   static const float nm_per_rad_per_bit;

   int16_t  inertia;
   uint16_t damping;
   uint16_t stiffness;
} __attribute__((__packed__));

//class StatusRequestCmdPayload{
//   // there is no payload for a status request command
//};

class BITErrorMsgPayload{
public:
   BITErrorMsgPayload();

   BITContext Context() const;
   bool BIT_Failure() const;
   bool BIT_OverTemperature() const;
   bool BIT_OverVoltage() const;
   bool BIT_UnderVoltage() const;
   bool BIT_OverCurrent() const;
   bool BIT_FOCInit() const;
   bool BIT_FOCMinSpeed() const;
   bool BIT_WrongDirection() const;
   bool BIT_SlaveFailure() const;

protected:
   uint8_t err_context;
   uint32_t err_type;
} __attribute__((__packed__));


class HsTelemetryMsgPayload{
public:
   HsTelemetryMsgPayload();

   float Position() const;
   float Velocity() const;
   float Torque() const;
   float MotorCurrent() const;

   bool SWLimit() const;
   bool HWLimit() const;
   bool Home() const;

protected:
   static const float rad_per_bit;
   static const float rad_per_sec_per_bit;
   static const float nm_per_bit;
   static const float amps_per_bit;

   int16_t position:12;
   int16_t velocity:12;
   int16_t spare:12;
   int16_t torque:12;
   int16_t motor_current:12;
   uint8_t  pos_limit:4;
} __attribute__((__packed__));


class LsTelemetryMsgPayload{
public:
   LsTelemetryMsgPayload();

   SWState SwState() const;

   bool BIT_Error() const;
   bool BIT_CriticalError() const;
   bool BIT_NonCriticalError() const;

   bool DebugEnabled() const;
   bool CurrentLimitReached() const;

   FOCState FocState() const;

   float BusVoltage() const;
   float BusCurrent() const;

   float MotorTemp() const;

protected:
   static const float volts_per_bit;
   static const float amps_per_bit;
   static const float celcius_per_bit;

   uint8_t  sw_state:4;
   uint8_t  bit_err_sts:2;
   uint8_t  debug_enabled:2;  // corresponds to whether medium-speed telemetry messages are sent?  ignored
   uint8_t  over_current:1;
   uint8_t  foc_state:3;
   uint8_t  fault:4;          // Current not used by hardware
   uint16_t bus_voltage:12;
   int16_t  bus_current:12;
   uint16_t motor_temp:12;
   uint8_t  spare:4;
} __attribute__((__packed__));


class StatusMsgPayload{
public:
   StatusMsgPayload();

   SWState SwState() const;

   bool BIT_Error() const;
   bool BIT_CriticalError() const;
   bool BIT_NonCriticalError() const;

   bool DebugEnabled() const;

protected:
   uint8_t sw_state:4;
   uint8_t bit_err_sts:2;
   uint8_t debug_enabled:2;
} __attribute__((__packed__));


class AckMsgPayload{
public:
   AckMsgPayload();

   MessageID Id() const;

protected:
   uint8_t msg_id;
} __attribute__((__packed__));


class NackMsgPayload{
public:
   NackMsgPayload();

   MessageID Id() const;
   CmdError Error() const;

protected:
   uint8_t msg_id;
   uint16_t cmd_err_id;
} __attribute__((__packed__));

} // namespace RAD

#endif /* RADMESSAGES_H_ */
