#ifndef DATA_VARIANT_H
#define DATA_VARIANT_H
/*
 * \file variant.h
 *
 * Header file to evaluation conditions defined on jLib primitive variants.
 *
 * THIS WORK CONTAINS VALUABLE CONFIDENTIAL AND PROPRIETARY INFORMATION.
 * DISCLOSURE OR REPRODUCTION WITHOUT THE WRITTEN AUTHORIZATION OF Applied
 * Perception IS PROHIBITED. THIS UNPUBLISHED WORK BY Applied Perception
 * IS PROTECTED BY THE LAWS OF THE UNITED STATES AND OTHER
 * COUNTRIES. IF PUBLICATION OF THE WORK SHOULD OCCUR, THE FOLLOWING NOTICE
 * SHALL APPLY.
 *
 * "COPYRIGHT (C) 2009 Applied Perception ALL RIGHTS RESERVED."
 *
 * Applied Perception DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL Applied Perception BE LIABLE FOR ANY SPECIAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 *
 * THE USER'S RIGHTS TO USE, MODIFY, REPRODUCE, RELEASE, PERFORM, DISPLAY,
 * OR DISCLOSE THE TECHNICAL DATA AND COMPUTER SOFTWARE IN THIS FILE IS
 * RESTRICTED BY THE Applied Perception LICENSE AGREEMENT PROVIDED WITH
 * DELIVERY OF THIS FILE. ANY REPRODUCTION OF TECHNICAL DATA, COMPUTER
 * SOFTWARE, OR PORTIONS THEREOF MARKED WITH THIS LEGEND MUST ALSO
 * REPRODUCE THE MARKINGS.
 */

#include <jaus_message.h> /* for jLibDataVariant_t & related */

#ifdef __cplusplus
extern "C" {
#endif

  /*!
   * \brief Convert a value pointed to by a void * to a Variant.
   *
   * \return 1 if successful, else 0
   */
  int ToVariant(jLibDataTypeEnumeration_t data_type,
                void *value,
                jLibDataVariant_t *var);

  /*!
   * \brief Convert a double to a numeric Variant, with more error checking.
   *
   * This function fail if the value of \c numeric_val is greater than
   * the max value of \c data_type.
   *
   * \return 1 if successful, else 0
   */
  int DoubleToVariant(jLibDataTypeEnumeration_t data_type,
                      double numeric_val,
                      jLibDataVariant_t *var);

  /*!
   * \brief Convert a a numeric Variant to a double.
   *
   * \return 1 if successful, else 0
   */
  int VariantToDouble(jLibDataVariant_t variant,
                      double *val);

  /*!
   * \brief Convert a ulong to a numeric Variant.
   *
   * This function will fail on assignment to an integer
   * type smaller than an unsigned long integer if \c numeric_val is
   * greater than the target \c data_type.
   *
   * \return 1 if successful, else 0
   */
  int UlongToVariant(jLibDataTypeEnumeration_t data_type,
                     unsigned long numeric_val,
                     jLibDataVariant_t *var);

  /*!
   * \brief Convert a a numeric Variant to a ulong.
   *
   * This function will fail if the integer part of a double cannot be
   * represented in an unsigned long integer.
   *
   * \return 1 if successful, else 0
   */
  int VariantToUlong(jLibDataVariant_t variant,
                     unsigned long *val);

  /*!
   * \brief Do a simple comparison of variants.
   *
   * \param[out]  result JLIB_TRUE if \c eval_expression() is successful
   *     and condition evaluates to True.  JLIB_FALSE if \c eval_expression()
   *     successful and condition evaluates to False.
   * \param lhs left-hand-side of comparison
   * \param compare one of BOUND_{EQ,NEQ,GTE,GT,LTE,LT}
   * \param rhs right-hand-side of comparision
   *
   * \return 1 for successful comparison, else 0.
   */
  int CompareVariant(int *result,
                     jLibDataVariant_t lhs,
                     jLibBoundaryTypeEnumeration_t compare,
                     jLibDataVariant_t rhs);
  /*!
   * \brief Evaluate a condiition defined on a jLibDataVariant_t value,
   *    per semantics of the JAUS RA3.3 Event mechanism.
   *
   * For point comparisons, (value > state.data, value < state.data,
   * value == state.data, value != state.data, value >= state.data,
   * and value <= state.data), only the \c state param is used.
   *
   * For range comparisons (value in [lower, upper], value in (lower,
   * upper), value not in [lower, upper] and value not in (lower,
   * upper)), only the \c {upper, lower}_limit parameters are used.
   *
   * If any type or value is invalid, or if the condition cannot otherwise
   * be evaluted, \c eval_expression() returns JLIB_FALSE.  See the log messages
   * for error details.
   *
   * \param[out]  result JLIB_TRUE if \c eval_expression() is successful
   *     and condition evaluates to True.  JLIB_FALSE if \c eval_expression()
   *     successful and condition evaluates to False.
   * \param value a jLib data element to be evaluated per the condition params
   *     that follow.
   * \param boundary_type - one of BOUND_EQ, BOUND_NEQ, BOUND_GT, BOUND_GTE,
   *      BOUND_GT, BOUND_LTE, BOUND,LT, BOUND_IN_INCL, BOUND_OUT_EXCL,
   *      BOUND_OUT_INCL, BOUND_OUT_EXCL
   * \param lower_limit
   * \param upper_limit
   * \param state
   *
   * \return - JLIB_TRUE if evaluation was successfully performed, result returned
   *      in result, else return JLIB_FALSE.
   */
    int EvalExpression( int *result,
                        jLibDataVariant_t value,
                        jLibBoundaryTypeEnumeration_t boundary_type,
                        jLibDataVariant_t lower_limit,
                        jLibDataVariant_t upper_limit,
                        jLibDataVariant_t state);

#ifdef __cplusplus
}
#endif

#endif
