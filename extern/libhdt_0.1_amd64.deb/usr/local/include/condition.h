/*
 * \file condition.h
 *
 * THIS WORK CONTAINS VALUABLE CONFIDENTIAL AND PROPRIETARY INFORMATION.
 * DISCLOSURE OR REPRODUCTION WITHOUT THE WRITTEN AUTHORIZATION OF Applied
 * Perception IS PROHIBITED. THIS UNPUBLISHED WORK BY Applied Perception
 * IS PROTECTED BY THE LAWS OF THE UNITED STATES AND OTHER
 * COUNTRIES. IF PUBLICATION OF THE WORK SHOULD OCCUR, THE FOLLOWING NOTICE
 * SHALL APPLY.
 *
 * "COPYRIGHT (C) 2009 Applied Perception ALL RIGHTS RESERVED."
 *
 * Applied Perception DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL Applied Perception BE LIABLE FOR ANY SPECIAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 *
 * THE USER'S RIGHTS TO USE, MODIFY, REPRODUCE, RELEASE, PERFORM, DISPLAY,
 * OR DISCLOSE THE TECHNICAL DATA AND COMPUTER SOFTWARE IN THIS FILE IS
 * RESTRICTED BY THE Applied Perception LICENSE AGREEMENT PROVIDED WITH
 * DELIVERY OF THIS FILE. ANY REPRODUCTION OF TECHNICAL DATA, COMPUTER
 * SOFTWARE, OR PORTIONS THEREOF MARKED WITH THIS LEGEND MUST ALSO
 * REPRODUCE THE MARKINGS.
 *
 */
#ifndef _CONDITION_H_
#define _CONDITION_H_

typedef void * Condition_t;

#ifdef __cplusplus
extern "C" {
#endif


  /*!
   * \brief Create and initialize a condition.
   *
   * Create and initialize a POSIX ( mutex, condition ) pair.  The
   * mutex is initialized as a recursive mutex, allowing multiple
   * AcquireCondition() calls by a thread, which must be followed by
   * the exact number of ReleaseCondition() calls.
   *
   * \return a valid condition variable, else NULL.
   */
  Condition_t CreateCondition();

  /*!
   * \brief Delete a condition variable.
   * 
   * \param condition a valid condition variable.
   *
   */
  void DeleteCondition(Condition_t condition);

  /*!
   * \brief Acquire the POSIX mutex associated with the condition.
   *
   *
   * 
   * \param condition a valid condition variable.
   *
   * \return 1 if successful, else 0.
   */
  int AcquireCondition(Condition_t condition);

  /*!
   * \brief Wait (no timeout) until the condition is signalled.
   *
   * If \c WaitCondition() returns true (1), then the caller
   * now holds the associated mutex.
   *
   * A 'success' return from this function does not guarantee that the
   * associated logical condition is true, but the mutex allows for
   * atomic checking to see if the associated logical condition is
   * true (e.g. buffer empty), and wait again if it is not.
   *
   * NOTE: On some platforms, like WIN32, the POSIX thread
   * implementation can lose a single signal.  An application should
   * either make sure that a condition is redundantly signalled if
   * necessary, or callers should use \c TimedWaitCondition() to make
   * sure a lost signal doesn't lead to a stuck thread.
   * 
   * \param condition a valid condition variable.
   *
   * \return 1 if successful, else 0.
   *
   * This call will fail if the caller's thread has not successfully
   * acquired the condition either via an explicit AcquireCondition()
   * or by returning successfully from a [Timed]WaitCondition().
   */
  int WaitCondition(Condition_t condition);

  /*!
   * \brief Same as \c WaitCondition(), but will return after a timeout if
   *     the condition has not been signalled via a Notify*().
   *
   * A 'success' return from this function does not guarantee that the
   * associated logical condition is true, but the mutex allows for
   * atomic checking to see if the associated logical condition is
   * true (e.g. buffer empty), and wait again if it is not.
   *
   * NOTE: For timeouts, any time measured between the call and the
   * return will consist of the timeout time, PLUS any additional time
   * blocked waiting to get the condition's associated POSIX mutex.
   * 
   * \param condition a valid condition variable.
   * \param timeout a floating point value indicating the maximum
   *      number of seconds to wait.
   *
   * \return 1 if successful, else 0.
   *
   * This call will fail if the caller's thread has not successfully
   * acquired the condition either via an explicit AcquireCondition()
   * or by returning successfully from a [Timed]WaitCondition().
   */
  int TimedWaitCondition(Condition_t condition, double timeout);

  /*!
   * \brief Release the POSIX mutex associated with \c condition.
   *
   * \param condition a valid condition variable.
   *
   * \return 1 if successful, else 0.
   */
  int ReleaseCondition(Condition_t condition);

  /*!
   * \brief Wake up one thread waiting on \c condition.
   *
   * If more than one thread is waiting, the system will arbitrarily
   * pick any one of the waiting threads.
   *
   * Internally, NotifyCondition() must first acquire the associated
   * mutex, before signalling.  Therefore NotifyCondition() will block
   * if another thread has acquired the condition via
   * AcquireCondition() or by returning from a Wait operation.
   * 
   * \param condition a valid condition variable.
   *
   * \return 1 if successful, else 0.
   */
  int NotifyCondition(Condition_t condition);


  /*!
   * \brief Wake up all threads waiting on \c condition.
   * 
   * \param condition a valid condition variable.
   *
   * \return 1 if successful, else 0.
   */
  int NotifyAllCondition(Condition_t condition);

#ifdef __cplusplus
}
#endif

#endif
