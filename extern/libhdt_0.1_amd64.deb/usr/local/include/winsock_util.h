#ifndef WINSOCK_UTIL_H
#define WINSOCK_UTIL_H
/* winsock_util.h
 *
 */

/* TODO: Build this out as needed. */
/* Get a fragment of errno.h */
#ifndef EOPNOTSUPP
#define EOPNOTSUPP 95	/* Operation not supported on transport endpoint */
#define EPFNOSUPPORT 96 /* Protocol family not supported */
#define ECONNRESET 104  /* Connection reset by peer */
#define ENOBUFS 105	/* No buffer space available */
#define EAFNOSUPPORT 106 /* Address family not supported by protocol family */
#define EPROTOTYPE 107	/* Protocol wrong type for socket */
#define ENOTSOCK 108	/* Socket operation on non-socket */
#define ENOPROTOOPT 109	/* Protocol not available */
#define ESHUTDOWN 110	/* Can't send after socket shutdown */
#define ECONNREFUSED 111	/* Connection refused */
#define EADDRINUSE 112		/* Address already in use */
#define ECONNABORTED 113	/* Connection aborted */
#define ENETUNREACH 114		/* Network is unreachable */
#define ENETDOWN 115		/* Network interface is not configured */
/* #define ETIMEDOUT 116		/* Connection timed out */
#define EHOSTDOWN 117		/* Host is down */
#define EHOSTUNREACH 118	/* Host is unreachable */
#define EINPROGRESS 119		/* Connection already in progress */
#define EALREADY 120		/* Socket already connected */
#define EDESTADDRREQ 121	/* Destination address required */
#define EMSGSIZE 122		/* Message too long */
#define EPROTONOSUPPORT 123	/* Unknown protocol */
#define ESOCKTNOSUPPORT 124	/* Socket type not supported */
#define EADDRNOTAVAIL 125	/* Address not available */
#define ENETRESET 126
#define EISCONN 127		/* Socket is already connected */
#define ENOTCONN 128		/* Socket is not connected */
#endif

/*!
 * \brief Get a string corresponding to a WSA error number.
 *
 * \param errnum - a number returned by WSAGetLastError
 *
 * \return pointer to error string.
 */
char *winsockerr(int errnum);

/*!
 * \brief Get a common networking error code, maps WSA errno to 
 *      POSIX errno.
 *
 * \param errnum - a number returned by WSAGetLastError
 *
 * \return POSIX errno, else 0.
 */
int GetCommonErrno(int errnum);

/*!
 * \brief Implementation of inet_aton() to use w/ winsock2.
 *
 * \param ip_addr - IP address in dotted notation, like "192.168.0.51"
 * \param[out] addr - an allocated sockaddr_in structure to receive results.
 *
 * \return 0 on failure, non-zero on success
 */
int inet_aton( char *ip_addr, struct in_addr *addr);

#endif
