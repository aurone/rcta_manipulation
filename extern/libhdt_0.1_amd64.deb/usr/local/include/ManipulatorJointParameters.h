// BEGIN_QNA_COPYRIGHT
// END_QNA_COPYRIGHT
// BEGIN_QNA_FILE_INFO

// ManipulatorJointParameters.h: Definition of a class that holds parameters which define how
//                               a joint of a serial-rigid-link manipulator is modeled.
// Created Jul 27, 2011 by mcsencsits
// Updated Sep 20, 2011 by mcsencsits

// END_QNA_FILE_INFO

#ifndef MANIPULATORJOINTPARAMETERS_H_
#define MANIPULATORJOINTPARAMETERS_H_

#include <string>

#include "ManipulatorJointType.h"

/**
 * \brief This class provides a container for storing and accessing all parameters used to model/describe a
 *  rigid-link joint of a manipulator.
 *
 *  All 'setter' methods return a reference to the instance.  This enables the <em>Named Parameter Idiom</em>.
 *  See: http://www.parashift.com/c++-faq-lite/ctors.html#faq-10.20
 *
 *  This class is designed to be a simple container and does not perform any sanity checks itself (e.g. does not ensure
 *  MinPosition() <= StowPosition() <= MaxPosition()).  It is expected that creators of ManipulatorJointParameters
 *  instances (e.g. the ManipulatorParameters class) will ensure sane data and that users will be prevented from changing
 *  values by being passed a const reference to a ManipulatorJointParameters instance.
 */
class ManipulatorJointParameters{
public:

   // Lifecycle
   ManipulatorJointParameters();                                              // default constructor
   ManipulatorJointParameters(const ManipulatorJointParameters& jointParams); // copy constructor
   ~ManipulatorJointParameters(); // destructor

   // Getters, these methods return the value of the associated parameter
   float DhAngle() const;
   float DhLength() const;
   float DhOffset() const;
   float DhTwist() const;
   ManipulatorJointType Type() const;

   float MinPosition() const;
   float MaxPosition() const;
   float StowPosition() const;

   float MaxVelocity() const;
   float MaxAcceleration() const;

   float Resolution() const;

   float EncOffset() const;
   float EncScale() const;

   std::string Name() const;


   // Setters, these methods set the value of the associated parameter and
   //  return a reference to this instance in order to enable the 'Named Parameter Idiom'
   //  see: http://www.parashift.com/c++-faq-lite/ctors.html#faq-10.20
   ManipulatorJointParameters& DhAngle(float val);
   ManipulatorJointParameters& DhLength(float val);
   ManipulatorJointParameters& DhOffset(float val);
   ManipulatorJointParameters& DhTwist(float val);
   ManipulatorJointParameters& Type(ManipulatorJointType type);

   ManipulatorJointParameters& MinPosition(float val);
   ManipulatorJointParameters& MaxPosition(float val);
   ManipulatorJointParameters& StowPosition(float val);

   ManipulatorJointParameters& MaxVelocity(float val);
   ManipulatorJointParameters& MaxAcceleration(float val);

   ManipulatorJointParameters& Resolution(float val);

   ManipulatorJointParameters& EncOffset(float val);
   ManipulatorJointParameters& EncScale(float val);

   ManipulatorJointParameters& Name(std::string val);

   // Operators, these methods provide some convenient functionality
   //ManipulatorJointParameters& operator= (const ManipulatorJointParameters& rhs); // copy assignment, will use the default
   bool operator==(const ManipulatorJointParameters& rhs) const;
   bool operator!=(const ManipulatorJointParameters& rhs) const;

   friend std::ostream& operator<< (std::ostream&, const ManipulatorJointParameters&); // stream operator for printing with streams
   std::string toString() const; // create string detailing parameter values for printing

private:

   float mDhAngle;  // Angle parameter for Denavit-Hartenberg representation of joint.
   float mDhLength; // Length parameter for Denavit-Hartenberg representation of joint.
   float mDhOffset; // Offset parameter for Denavit-Hartenberg representation of joint.
   float mDhTwist;  // Twist parameter for Denavit-Hartenberg representation of joint.
   ManipulatorJointType mType; // Value representing joint type.

   float mMinPosition;  // Minimum joint position limit
   float mMaxPosition;  // Maximum joint position limit
   float mStowPosition; // Preferred joint stow position

   float mMaxVelocity;     // Maximum joint velocity
   float mMaxAcceleration; // Maximum joint acceleration

   float mResolution; // Minimum measurable change in joint position

   float mEncOffset; // Encoder offset value, used to convert feedback value into position relative to kinematic model
   float mEncScale;  // Encoder scale value, used to convert feedback value into position relative to kinematic model

   std::string mName; // Given name for joint
};

#endif /* MANIPULATORJOINTPARAMETERS_H_ */
