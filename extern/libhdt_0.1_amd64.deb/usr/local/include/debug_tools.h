#ifndef DEBUG_TOOLS_H
#define DEBUG_TOOLS_H
/**
 *
 * \file debug_tools.h
 *
 * Based on:
 * Id: tools.h,v 1.16 2007/03/13 18:11:01 jaus Exp
 * Revision: 1.16
 * Date: 2007/03/13 18:11:01
 *
 * THIS WORK CONTAINS VALUABLE CONFIDENTIAL AND PROPRIETARY INFORMATION.
 * DISCLOSURE OR REPRODUCTION WITHOUT THE WRITTEN AUTHORIZATION OF Applied
 * Perception IS PROHIBITED. THIS UNPUBLISHED WORK BY Applied Perception
 * IS PROTECTED BY THE LAWS OF THE UNITED STATES AND OTHER
 * COUNTRIES. IF PUBLICATION OF THE WORK SHOULD OCCUR, THE FOLLOWING NOTICE
 * SHALL APPLY.
 *
 * "COPYRIGHT (C) 2003 Applied Perception ALL RIGHTS RESERVED."
 *
 * Applied Perception DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL Applied Perception BE LIABLE FOR ANY SPECIAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
/*****************************************************************************/
/* General Constants */

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#ifndef ON
#define ON   1
#define OFF  0
#endif

/*****************************************************************************/
/* debugging macro tools */

#define DEBUG_ON

#ifdef DEBUG_PTHREAD
#include <pthread.h>
#if defined(LINUX)
#define pthread_mutex_lock(x)  {jLibOutputUserMessage(JLIB_PRINT_BASIC, "+++lock: func: %s arg %s count %d (file: %s, line: %d)\n", __FUNCTION__, #x, *(x.__data.__count), __FILE__, __LINE__); pthread_mutex_lock(x);}
#define pthread_mutex_unlock(x)  {jLibOutputUserMessage(JLIB_PRINT_BASIC, "---unlock: func: %s arg %s count %d (file: %s, line: %d)\n", __FUNCTION__, #x, *(x.__data.__count), __FILE__, __LINE__); pthread_mutex_unlock(x);}
#define pthread_rwlock_wrlock(x)  {jLibOutputUserMessage(JLIB_PRINT_BASIC, "+++wrlock: func: %s arg %s count %d (file: %s, line: %d)\n", __FUNCTION__, #x, *(x.__data.__nr_readers), __FILE__, __LINE__); pthread_rwlock_wrlock(x);}
#define pthread_rwlock_rdlock(x)  {jLibOutputUserMessage(JLIB_PRINT_BASIC, "+++rdlock: func: %s arg %s count %d (file: %s, line: %d)\n", __FUNCTION__, #x, *(x.__data.__nr_readers), __FILE__, __LINE__); pthread_rwlock_rdlock(x);}
#define pthread_rwlock_unlock(x)  {jLibOutputUserMessage(JLIB_PRINT_BASIC, "---rwunlock: func: %s arg %s count %d (file: %s, line: %d)\n", __FUNCTION__, #x, *(x.__data.__nr_readers), __FILE__, __LINE__); pthread_rwlock_unlock(x);}
#else
#define pthread_mutex_lock(x)  {jLibOutputUserMessage(JLIB_PRINT_BASIC, "+++lock: func: %s arg %s (file: %s, line: %d)\n", __FUNCTION__, #x, __FILE__, __LINE__); pthread_mutex_lock(x);}
#define pthread_mutex_unlock(x)  {jLibOutputUserMessage(JLIB_PRINT_BASIC, "---unlock: func: %s arg %s (file: %s, line: %d)\n", __FUNCTION__, #x, __FILE__, __LINE__); pthread_mutex_unlock(x);}
#define pthread_rwlock_wrlock(x)  {jLibOutputUserMessage(JLIB_PRINT_BASIC, "+++wrlock: func: %s arg %s (file: %s, line: %d)\n", __FUNCTION__, #x, __FILE__, __LINE__); pthread_rwlock_wrlock(x);}
#define pthread_rwlock_rdlock(x)  {jLibOutputUserMessage(JLIB_PRINT_BASIC, "+++rdlock: func: %s arg %s (file: %s, line: %d)\n", __FUNCTION__, #x, __FILE__, __LINE__); pthread_rwlock_rdlock(x);}
#define pthread_rwlock_unlock(x)  {jLibOutputUserMessage(JLIB_PRINT_BASIC, "---rwunlock: func: %s arg %s (file: %s, line: %d)\n", __FUNCTION__, #x, __FILE__, __LINE__); pthread_rwlock_unlock(x);}
#endif
#endif

#ifdef  DEBUG_ON
#define DEBUG_(fmt, arg)      PRINT_F_L printf(fmt, arg);
#else
#define DEBUG_(fmt, arg)
#endif

#ifdef DEBUG_ON
#define DEBUG_I(arg)         DEBUG_("arg = %d\n", arg);
#define DEBUG_F(arg)         DEBUG_("arg = %f\n", arg);
#define DEBUG_S(arg)         DEBUG_("%s\n", arg);
#define DEBUG_HERE(arg)      DEBUG_("At here statement %d\n", arg);
#else
#define DEBUG_I(arg)
#define DEBUG_F(arg)
#define DEBUG_S(arg)
#define DEBUG_HERE(arg)
#endif

#define DI(arg)              DEBUG_I(arg)
#define DF(arg)              DEBUG_F(arg)
#define DS(arg)              DEBUG_S(arg)
#define DH(arg)              DEBUG_HERE(arg)

#ifdef DEBUG_ON
#define ASSERT(f)  assert(f)
#else
#define ASSERT(f)
#endif

#endif
